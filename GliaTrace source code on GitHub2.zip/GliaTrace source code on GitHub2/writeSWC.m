function writeSWC(cellinfo, cn)
% write the output in swc file format
%     writeSWC(cellinfo, nn);
%
%   cellinfo    cell information
%   nn          file number
%   cn          cell number
%================================
% Nov. 2016
% Mahmoud Abdolhoseini
% The University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
%================================




%cell info
ce=cellinfo.SomaCentroid;   %centroid of the somas
[~,name,~] = fileparts(cellinfo.filename{cellinfo.counter});
ims = cellinfo.imsize;  %image size
num_cell = length(cellinfo.pci);    %number of cells

if nargin==1, cn=1:num_cell; end

%soma info
somainfo=regionprops(cellinfo.soma, 'PixelList');

% make a result folder to store results
if ~exist([cellinfo.filepath,'results'],'dir')
    mkdir(cellinfo.filepath,'results')
end
filepath=[cellinfo.filepath,'results\'];

% check if it is 3D
if ims(3)==1
    threeD=0;
else
    threeD=1;
end

%write the swc file format
if threeD
    fileID = fopen([filepath,name,'_3D','.swc'],'w');
else
    fileID = fopen([filepath,name,'_2D','.swc'],'w');
end
fprintf(fileID,  '# This swc file is the output of GliaTrace programmed by Mahmoud Abdolhoseini,\n');
fprintf(fileID,  '# mahmoud.abdolhoseini@uon.edu.au\n#\n');
fprintf(fileID, ['# Image properties: name:            ', name,'\n']);
fprintf(fileID, ['#                   x-y resolution:  ', num2str(cellinfo.para.xyRes),' micrometer/pixel\n']);
if threeD
    fprintf(fileID, ['#                   z-step size:     ', num2str(cellinfo.para.zStep),' micrometer\n']);
    fprintf(fileID, ['#                   size (voxel):    ', num2str(ims(1)),' * ',num2str(ims(2)),' * ',num2str(ims(3)),'\n#\n']);
else
    fprintf(fileID, ['#                   size (pixel):    ', num2str(ims(1)),' * ',num2str(ims(2)),'\n#\n']);
end
% fprintf(fileID, ['# Run time: ', num2str(cellinfo.recon_time),' second.\n']);
fprintf(fileID, ['# ', datestr(datetime('now')),'\n']);
summ=0;
for n=cn
    
    %parent-child id
    pci = cellinfo.pci{n};  
    
    %specify cell number
    fprintf(fileID,'#\n#\n#\n#Cell No. %d\n', n);
    
    %column explanation
    fprintf(fileID,'#No. type x y z radius parent\n');
    
    %soma location
%     sl=somainfo(n).PixelList;
%     ss=size(sl,1);
%     fprintf(fileID,'%d 1 %d %d %d 2 -1\n', [summ+(1:ss);sl']);
%     summ=summ+ss;
    
    if isempty(pci); continue, end
    cec = cellinfo.queue{n}(1,:); %soma centroid in the cropped area
    radii=cellinfo.radii{n}(1:end-1)'/cellinfo.para.xyRes; %branch radii in pixel
    
    % parent id
    pid = pci(:,1);
    le = length(pid);
    
    %arrange the pid when the children are in order
    for k=1:le
        pid(pci(:,1)==pci(k,2))=k+1;
    end
    
    % children locations
    c = cellinfo.queue{n}(pci(:,2),:);  
    
    % shift the locations to the original image size
    c(:,1) = c(:,1) + ce(n,1) - cec(1);
    c(:,2) = c(:,2) + ce(n,2) - cec(2); 
    if threeD
        c(:,3) = c(:,3) + ce(n,3) - cec(3);
        
        %root node 
        fprintf(fileID,'%d 1 %d %d %d %2.2f -1\n', [summ+1;ce(n,:)';2]);
        
        %other nodes
        fprintf(fileID,'%d 3 %d %d %d %2.2f %d\n', [summ+1+(1:le);c';radii;pid'+summ]);
        
    else %2D
        fprintf(fileID,'%d 1 %d %d 1 %1.2f -1\n', [summ+1;ce(n,:)';2]);
        fprintf(fileID,'%d 3 %d %d 1 %1.2f %d\n', [summ+1+(1:le);c';radii;pid'+summ]);
    end
    summ=summ+le+1;
end
fclose(fileID);


%write the swc file format for the smoothed path
if isfield(cellinfo, 'path')
    if threeD
        fileID = fopen([filepath,name,'_smoothed_3D','.swc'],'w');
    else
        fileID = fopen([filepath,name,'_smoothed_2D','.swc'],'w');
    end
    fprintf(fileID,  '# This swc file is the output of GliaTrace programmed by Mahmoud Abdolhoseini,\n');
    fprintf(fileID,  '# mahmoud.abdolhoseini@uon.edu.au\n#\n');
    fprintf(fileID, ['# Image properties: name:            ', name,'\n']);
    fprintf(fileID, ['#                   x-y resolution:  ', num2str(cellinfo.para.xyRes),' micrometer/pixel\n']);
    if threeD
        fprintf(fileID, ['#                   z-step size:     ', num2str(cellinfo.para.zStep),' micrometer\n']);
        fprintf(fileID, ['#                   size (voxel):    ', num2str(ims(1)),' * ',num2str(ims(2)),' * ',num2str(ims(3)),'\n#\n']);
    else
        fprintf(fileID, ['#                   size (pixel):    ', num2str(ims(1)),' * ',num2str(ims(2)),'\n#\n']);
    end
    fprintf(fileID, ['# Run time: ', num2str(cellinfo.recon_time),' seconds.\n']);
    fprintf(fileID, ['# ', datestr(datetime('now')),'\n']);
    summ=0;
    for n=cn
        
        path = cellinfo.path{n};
        if isempty(path); continue, end
        cec = cellinfo.queue{n}(1,:); %soma centroid in the cropped area
        
        %find parent id
        ind=find(path(:,1)==0);
        id=zeros(length(ind),1);
        for m=1:length(ind)
            pi=path(ind(m)+1,:);
            if threeD  
                id(m)=find(path(:,1)==pi(1) & path(:,2)==pi(2) & path(:,3)==pi(3) ,1,'first');
            else
                id(m)=find(path(:,1)==pi(1) & path(:,2)==pi(2) ,1,'first');
            end
            
            %update indices
            idx=find(id(m)<ind, 1, 'first');
            id(m)=id(m) - 2*(idx-1);
            ind(m)=ind(m) - 2*(m-1);
        end
        
        %making No id and parent id (pid)
        le = size(path,1);
        if isempty(ind)
            No=1:le;
            pid=[-1,1:(le-1)];
        else
            tmp=le-2*length(ind);
            No=1:tmp;
            pid=[-1,1:(tmp-1)];
            pid(ind)=id;
            path(find(path(:,1)==0)+1,:)=0;
            path=path(logical(path(:,1)),:);
        end
%         le = size(path,1);
%         No = 1:le;
%         pid=[-1,1:(le-1)];
%         if ~isempty(ind)
%             No(ind)=0;
%             No(ind+1)=0;
%             pid(ind+2)=id;
%         end
%         No=No(logical(No));
%         pid=pid(No);
%         path=path(No,:);
        
        % shift the path to original location
        path(:,1) = path(:,1) + ce(n,1) - cec(1);
        path(:,2) = path(:,2) + ce(n,2) - cec(2);
        
        if threeD
            path(:,3) = path(:,3) + ce(n,3) - cec(3);
            
            %specify cell number
            fprintf(fileID,'#\n#\n#\n#Cell No. %d\n', n);
            
            %column explanation
            fprintf(fileID,'#No. type x y z radius parent\n');
            
            %soma location
%             sl=somainfo(n).PixelList;
%             ss=size(sl,1);
%             fprintf(fileID,'%d 1 %d %d %d 2 -1\n', [summ+(1:ss);sl']);
%             summ=summ+ss;
            
%             %fake points
%             fp=sl; fp(:,2)=fp(:,2)+1;
%             fprintf(fileID,'%d 1 %d %d %d 2 %d\n', [summ+(1:ss);fp';summ-ss+(1:ss)]);
%             summ=summ+ss;
            
            %specify root node as an estimation of soma
            fprintf(fileID,'%d 1 %d %d %d %1.2f %d\n', [1+summ;path(1,:)';2;-1]);
            
            %specify branches
            fprintf(fileID,'%d 3 %d %d %d 2 %d\n', [No(2:end)+summ; path(2:end,:)'; pid(2:end)+summ]);
            
        else %2D
            %specify cell number
            fprintf(fileID,'#\n#\n#\n#Cell No. %d\n', n);
            
            %column explanation
            fprintf(fileID,'#No. type x y z radius parent\n');
            
            %specify root node as an estimation of soma
            fprintf(fileID,'%d 1 %d %d 1 %1.2f %d\n', [1+summ;path(1,:)';2;-1]);
            
            %specify branches
            fprintf(fileID,'%d 3 %d %d 1 2 %d\n', [No(2:end)+summ; path(2:end,:)'; pid(2:end)+summ]);
        end
        summ = summ+No(end);
    end
    fclose(fileID);
end




