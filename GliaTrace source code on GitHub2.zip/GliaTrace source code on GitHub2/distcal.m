function [D, nid] = distcal(cellinfo, conn_nodes, node, BW)
%----->> Distance calculation
%   Euclidean distances from a node (=conn_nodes(end)) to seed points that
%   are CONNECTED to it in a limited area around it are computed WHILE 
%   ignoring the nodes that have been already connected (conn_nodes)
%
% [eucdist, nid] = distcal(cellinfo, conn_nodes, BW)
% 
% inputs:     
%       cellinfo        -cell information
%       conn_nodes      -the nodes that have been already connected. Its
%                        last element (conn_nodes(end)) specify the node
%                        that distcal function computes distances for it
%       BW              -cell pixels (which specify if a seed point is
%                        connected to the node or not)
%             
% outputs:     
%       eucdist         -Euclidean distances from the node to seed points 
%                        that are CONNECTED to it        
%       nid             -queue id of the nodes to which geo dists are calculated
% 
%==============================
% Author: Mahmoud Abdolhoseini,
% The University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
% Dec., 2015
% May,  2016    Upgraded to 3D
%==============================

ind = find(~cellfun(@isempty, cellinfo.queue), 1, 'last');
queue = cellinfo.queue{ind};
nsp   = cellinfo.nsp{ind};

[yl, xl, zl] = size(BW);
if zl==1
    threeD = 0;
    % maximum distance (md) specify an area around the node in which distances will be calculated
    md = ceil(1.7/cellinfo.para.xyRes);
else
    threeD = 1;
    md = ceil(1.7/cellinfo.para.xyRes);
end

% the given node and its location
% node = conn_nodes(end);
x = queue(node,1);
y = queue(node,2);
if threeD; z = queue(node,3); end

% ranges
xr = [x-md, x+md]; xr(xr(1)<1,1)=1; xr(xr(2)>xl,2)=xl;
yr = [y-md, y+md]; yr(yr(1)<1,1)=1; yr(yr(2)>yl,2)=yl;
if threeD
%     zmd = ceil(md / scaling);
%     zr = [z-zmd, z+zmd]; zr(zr(1)<1,1)=1; zr(zr(2)>zl,2)=zl;
    
    if z==1, zr=[1, 2];
    elseif z==zl, zr=[zl-1, zl];
    else
        zr=[z-1, z+1]; 
    end
end

% crop bw area with defined ranges
if threeD
    cbw  = BW(yr(1):yr(2), xr(1):xr(2), zr(1):zr(2));
else
    cbw  = BW(yr(1):yr(2), xr(1):xr(2));
end

% the node new location in the cropped area
if xr(1)==1; X=x; else, X=1+md; end
if yr(1)==1; Y=y; else, Y=1+md; end    
if threeD
    if zr(1)==1; Z=z; else, Z=2; end
    nnl = sub2ind(size(cbw),Y,X,Z);  % the node new location
else
    nnl = sub2ind(size(cbw),Y,X);
end

% all the seed points in the cropped area
if threeD
    ind = (queue(:,1) >= xr(1)) & (queue(:,1) <= xr(2)) & ...
        (queue(:,2) >= yr(1)) & (queue(:,2) <= yr(2))& ...
        (queue(:,3) >= zr(1)) & (queue(:,3) <= zr(2));
else
    ind = (queue(:,1) >= xr(1)) & (queue(:,1) <= xr(2)) & ...
        (queue(:,2) >= yr(1)) & (queue(:,2) <= yr(2));
end

% remove SPs that are already connected
ind(conn_nodes) = 0;
idx = find(ind);

% seed point indices in the cropped area
spx  = queue(ind,1) + X - x;
spy  = queue(ind,2) + Y - y;
if threeD
    spz  = queue(ind,3) + Z - z;
    id = sub2ind(size(cbw), spy, spx, spz);
else
    id = sub2ind(size(cbw), spy, spx);
end

% before Euclidean distance calculation, remove seed points that are not
% connected to the node
lm = bwlabeln(cbw);
na = lm==lm(nnl);
id1 = na(id);
ind(idx(~id1))=0;
idx = idx(id1);
spx=spx(id1);
spy=spy(id1);

% Euclidean distance
if threeD
    spz=spz(id1);
    eucdist = sqrt( ((spx-X)*cellinfo.para.xyRes).^2 + ...
        ((spy-Y)*cellinfo.para.xyRes).^2 + ((spz-Z)*cellinfo.para.zStep).^2);
else
    eucdist = sqrt((spx-X).^2 + (spy-Y).^2)*cellinfo.para.xyRes;
end


if isempty(eucdist)
    D=Inf;
    nid=0;
else
    
    % count the number of nodes in each level
    lnsp    = length(nsp);
    new_nsp = zeros(1,lnsp);    % number of nodes in each level
    sum1    = zeros(1,lnsp+1);
    sum2    = zeros(1,lnsp+1);
    for n = 1:lnsp
        new_nsp(n) = nnz(ind(sum1(n)+1:sum1(n)+nsp(n)));
        sum1(n+1)  = sum1(n) + nsp(n);
        sum2(n+1)  = sum2(n) + new_nsp(n);
    end
    
    if threeD
        D   = Inf*ones(4,1,lnsp);
        nid = zeros(4,1,lnsp);
        for n = 1:lnsp
            r=sum2(n)+1:sum2(n+1);
            if isempty(r), continue, end
            tmp=[eucdist(r), idx(r)];
            
            if z==1
                id1=spz(r)==1;
                id2=spz(r)==2;
                tmp1=tmp(id1,:);
                tmp2=tmp(id2,:);
                if ~isempty(tmp1)
                    [D(1,1,n), I]=min(tmp1(:,1));
                    nid(1,1,n)=tmp1(I,2);
                end
                if ~isempty(tmp2)
                    [D(2,1,n), I]=min(tmp2(:,1));
                    nid(2,1,n)=tmp2(I,2);
                end

                if size(tmp1,1)>1
                    [a,b]=sort(tmp1(:,1));
                    D(3,1,n)=a(2);
                    nid(3,1,n)=tmp1(b(2),2);
                end

            elseif z==zl
                id1=spz(r)==1;
                id2=spz(r)==2;
                tmp1=tmp(id1,:);
                tmp2=tmp(id2,:);
                if ~isempty(tmp1)
                    [D(1,1,n), I]=min(tmp1(:,1));
                    nid(1,1,n)=tmp1(I,2);
                end
                if ~isempty(tmp2)
                    [D(2,1,n), I]=min(tmp2(:,1));
                    nid(2,1,n)=tmp2(I,2);
                end

                if size(tmp2,1)>1
                    [a,b]=sort(tmp2(:,1));
                    D(3,1,n)=a(2);
                    nid(3,1,n)=tmp2(b(2),2);
                end
                
            else
                id1=spz(r)==1;
                id2=spz(r)==2;
                id3=spz(r)==3;
                
                tmp1=tmp(id1,:);
                tmp2=tmp(id2,:);
                tmp3=tmp(id3,:);
                
                if ~isempty(tmp1)
                    [D(1,1,n), I]=min(tmp1(:,1));
                    nid(1,1,n)=tmp1(I,2);
                end
                if ~isempty(tmp2)
                    [D(2,1,n), I]=min(tmp2(:,1));
                    nid(2,1,n)=tmp2(I,2);
                end
                if ~isempty(tmp3)
                    [D(3,1,n), I]=min(tmp3(:,1));
                    nid(3,1,n)=tmp3(I,2);
                end

                if size(tmp2,1)>1
                    [a,b]=sort(tmp2(:,1));
                    D(4,1,n)=a(2);
                    nid(4,1,n)=tmp2(b(2),2);
                end
            end
        end
    else
        
        % one column will be assigned to each set of nodes that belong to a same level
        dim   = max(new_nsp);
        temp  = Inf*ones(dim,1,lnsp);
        nid   = zeros(dim,1,lnsp);
        for n = 1:lnsp
            temp(1:new_nsp(n),1,n)  = eucdist(sum2(n)+1:sum2(n+1));
            nid(1:new_nsp(n),1,n)   = idx(sum2(n)+1:sum2(n+1));
            
            % sort them to pick a portion of them that are minimum
            [temp(:,1,n), I] = sort(temp(:,1,n));
            nid(:,1,n) = nid(I,1,n);
        end
        
        % Note: we don't need all the nodes, just an amount that assure us of connectivity
        p = 4; % pick p number of nodes in each level
        if p<=dim
            D = temp(1:p,1,:);
            nid     = nid(1:p,1,:);
        else
            D = padarray(temp, p-dim, Inf, 'post');
            nid     = padarray(nid, p-dim, 0, 'post');
        end
    end
    
end







