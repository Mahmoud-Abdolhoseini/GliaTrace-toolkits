function cellinfo = traceCell(cellinfo, imarray)
%----->>   Reconstruct cells from microscopy images
%   output:
%       -cellinfo   cell information
%
%   inputs:
%       -cellinfo
%       -image
%       -n          file number
%   
%
%=================================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% Apr. 2017
%=================================



if cellinfo.para.load3Dstack && cellinfo.para.threeD
    image = imarray.threeD;
else
    image = imarray.twoD.gray;
end

t=tic;
%find soma and background levels
cellinfo = SomaBackgroundLevel(cellinfo, image);
cellinfo.time.tSoma=toc(t);

t=tic;
%main tracing function
cellinfo = main_trace(cellinfo, image);
cellinfo.time.tMain=toc(t);

%check if any cell is found
if isempty(cellinfo.soma), return, end

t=tic;
%remove the cells in touch with the border
if cellinfo.para.remove_cell_intouchwith_border
    cellinfo = removecell(cellinfo);
end
cellinfo.time.tRemoveCell=toc(t);

%check if any cell is found
if isempty(cellinfo.SomaCentroid), return, end

t=tic;
%prune the tree
cellinfo = PruneTree(cellinfo);
cellinfo.time.tPrune=toc(t);

t=tic;
%find the thickness of the branches
cellinfo = BranchThickness(cellinfo);
cellinfo.time.tThickness=toc(t);

t=tic;
%quantification
if cellinfo.para.spreadsheet
    cellinfo = quantifycell(cellinfo);
end
cellinfo.time.tQuant=toc(t);

%smooth the path using Fast Marching Method (FMM)
if cellinfo.para.smoothit
    cellinfo = SmoothPath(cellinfo, image);
end

%write the output in swc file format
if cellinfo.para.swcfile
    writeSWC(cellinfo);
end

% plot cell
plotcell(cellinfo, imarray)














