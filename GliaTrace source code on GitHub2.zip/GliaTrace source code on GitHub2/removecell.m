function cellinfo = removecell(cellinfo)
%
%------ remove the cells in touch with border
%
%   cellinfo = removecell(cellinfo)
%
%   cellinfo        - cell information
%
%==============================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% May. 2016
%==============================


% cell info
yl = cellinfo.imsize(1);
xl = cellinfo.imsize(2);
zl = cellinfo.imsize(3);
if zl==1
    threeD=0;
    win = ceil(1.5/cellinfo.para.xyRes);  %length of sampling window in pixel
else
    threeD=1;
    win = ceil(1.7/cellinfo.para.xyRes);
    mcrZ=ceil(cellinfo.para.MaxCellRadius / cellinfo.para.zStep);
end
rex=mod(xl,win); rex(rex==0)=win;
rey=mod(yl,win); rey(rey==0)=win;
mcrX=ceil(cellinfo.para.MaxCellRadius / cellinfo.para.xyRes);


% somas info
somas = cellinfo.soma;
stats = regionprops(cellinfo.soma, 'BoundingBox', 'Centroid', 'PixelIdxList');
num_cell = length(stats);
if num_cell==0; return, end
ce  = round(cat(1, stats.Centroid));     % soma centroids
% bb  = round(cat(1, stats.BoundingBox));  % bounding boxes around somas


% new centroids in cell cropped area
nce=ce; %pre-allocation
nce(:,1) = mcrX+1;
nce(:,2) = mcrX+1;
ind = ce(:,1) - nce(:,1) < 0; nce(ind,1)=ce(ind,1);
ind = ce(:,2) - nce(:,2) < 0; nce(ind,2)=ce(ind,2);
if threeD
    nce(:,3) = mcrZ+1;
    ind = ce(:,3) - nce(:,3) < 0; nce(ind,3)=ce(ind,3);
end

% create xy box around each cell to check if the cell is capable of touching border
xrange(:,1) = ce(:,1) - mcrX;
xrange(:,2) = ce(:,1) + mcrX;
yrange(:,1) = ce(:,2) - mcrX;
yrange(:,2) = ce(:,2) + mcrX;


ind = false(num_cell,1);    % index of the cell in touch with border
for ii = 1:num_cell
    
    % check if the cell is capable of touching border
    if xrange(ii,1)>1 && yrange(ii,1)>1 && xrange(ii,2)<xl && yrange(ii,2)<yl
        continue
    end

    queue = cellinfo.queue{ii}; % seed point locations
    pci = cellinfo.pci{ii};     % parent-child id
    c = queue(pci(:,2),:);      % child
    
    % shift to original image size
    c(:,1) = c(:,1) + ce(ii,1) - nce(ii,1);
    c(:,2) = c(:,2) + ce(ii,2) - nce(ii,2);
    if threeD
        c(:,3) = c(:,3) + ce(ii,3) - nce(ii,3);
    end
    
    % check if the cell is in touch with border
    if ~isempty(find(c(:,1)<=win,1)) || ~isempty(find(c(:,2)<=win,1)) || ...
           ~isempty(find(c(:,1)>xl-rex,1)) || ~isempty(find(c(:,2)>yl-rey,1))
        ind(ii)=true;
    end
      
end

% remove the cell in touch with border
somas(cat(1, stats(ind).PixelIdxList))=0;

% update cellinfo
cellinfo.soma = somas;
cellinfo.pci  = cellinfo.pci(~ind);
cellinfo.queue= cellinfo.queue(~ind);
cellinfo.nsp = cellinfo.nsp(~ind);
cellinfo.SomaCentroid=ce(~ind,:);




