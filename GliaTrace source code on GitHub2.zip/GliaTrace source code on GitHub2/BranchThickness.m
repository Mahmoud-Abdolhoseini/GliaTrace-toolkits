function cellinfo = BranchThickness(cellinfo)
%
%To find the thickness of the branches
%   cellinfo = BranchThickness(cellinfo);
%
%
%
%=================================
% Dec. 2016
% Mahmoud Abdolhoseini
% mahmoud.abdolhoseini@uon.edu.au
% University of Newcastle
%=================================
%


%cell info
zl = cellinfo.imsize(3);    %number of slices
num_cell = length(cellinfo.pci);    %number of cells
xS=cellinfo.para.xyRes;

% check if it is 3D
if zl==1
    threeD=0;
else
    threeD=1;
    zS = cellinfo.para.zStep;
end


%to find radii around each point in pci (parent-child id) and soma radius
cellinfo.radii = cell(num_cell,1);
for n=1:num_cell
    
    pci = cellinfo.pci{n};
    npci = cellinfo.npci{n};    %not pruned pci
    if isempty(pci); continue, end
    lep=size(pci,1);
    radii = zeros(lep+1,1);
    queue = cellinfo.queue{n};  %queue of seed points
    
    %estimate soma radius
    ce=queue(1,:);  %centroid
    ch=npci(npci(:,1)==1,2);  %chilren
    chl=queue(ch,:);    %children location
    if threeD
        soma_radius = mean(sqrt(((ce(1)-chl(:,1))*xS).^2 + ((ce(2)-chl(:,2))*xS).^2 + ((ce(3)-chl(:,3))*zS).^2));
    else
        soma_radius = mean(sqrt((ce(1)-chl(:,1)).^2 + (ce(2)-chl(:,2)).^2))*xS;
    end
    
    %radii around each point
    for m=1:size(pci,1)
        sn=pci(m,2);    %start node
        en=zeros(10,1); %endnodes
        en=endnodeFun(pci,npci,sn,en);
        en=nonzeros(en);
        if isempty(en), continue, end
        enl=queue(en,:);
        snl=queue(sn,:);
        if threeD
            dist=sqrt(((enl(:,1)-snl(1))*xS).^2 + ((enl(:,2)-snl(2))*xS).^2 + ((enl(:,3)-snl(3))*zS).^2);
        else
            dist=sqrt((enl(:,1)-snl(1)).^2 + (enl(:,2)-snl(2)).^2)*xS;
        end
        radii(m)=min(dist);
    end
    
    if nnz(radii)==0
        radii(1:lep)=xS;
        radii(lep+1)=soma_radius;
        cellinfo.radii{n}=radii;
        continue
    end
        
    
    %mask the radii more than the average
    idx  = logical(radii);
    ra   = radii(idx);
    mask = mean(ra);
    ra(ra>mask) = mask;
    radii(idx)  = ra;
    
    %put the average into rootnode children
    idx = pci(:,1)==1;
    temp=radii(idx);
    temp(temp==0)=mean(nonzeros(radii));
    radii(idx)=temp;
    
    
    %estimate the value of zero places in radii vector using the value of
    %ancestors and descendants
    sn=1;   %start node
    Aid=[]; %Ancestor ids
    radii=EstimateRadii(pci, radii, sn, Aid);
    
    
    %smooth the radii vector using moving average
    sn=1;   %start node
    Aid=[]; %Ancestor ids
    radii=SmoothRadii(pci, radii, sn, Aid);

    
    %store the radii vector
    radii(lep+1)=soma_radius;
    cellinfo.radii{n}=radii;
end



%--------------------------------------------function endnodeFun
    function en=endnodeFun(pci, npci, sn, en)
       % find all endnodes (en) connected to a start node (sn) using not pruned pci (npci)
       % npci: not pruned pci
       % sn: start node
       % en: end nodes
       %
       
       c=npci(npci(:,1)==sn ,2);   %children
       c=c(~ismember(c,pci(:,2)));
       if isempty(c), return, end
       
       lc=length(c);
       for k=1:lc
           e=c(k);
           tmp=npci(npci(:,1)==c(k),2);
           while length(tmp)==1
               e=tmp;
               tmp=npci(npci(:,1)==tmp,2);
           end
                   
           if isempty(tmp)
               ind=find(en,1,'last');
               if isempty(ind), ind=0; end
               en(ind+1)=e;
           end
%            else
%                en=endnodeFun(pci, npci, e, en);
%            end
       end 
    end
%-------------------------------------------end of endnodeFun


%-------------------------------------------EstimateRadii function
    function radii = EstimateRadii(pci, radii, sn, Aid)
        %Estimate values of zero places in radii vector
        %pci    -parent-child id
        %radii  -radii vector of the points lie on the branches
        %sn     -start node
        %Aid    -Ancestor ids
        %
        
        cid=find(pci(:,1)==sn);  %children id
        for k=1:length(cid)
            ind=zeros(1000,1);
            tmp=cid(k);
            co=0;
            while length(tmp)==1
                co=co+1;
                ind(co)=tmp;
                if radii(tmp), break; end
                tmp = find(pci(:,1)==pci(tmp,2));
            end
            ind=ind(1:co);
            
            %add ancestor ids
            id = [Aid;ind];
            
            
            if length(tmp)>1
                radii = EstimateRadii(pci, radii, pci(id(end),2), id);
            else
                a=radii(id(1));
                b=radii(id(end)); b(b==0)=xS;
                if logical(b-a)
                    c=(b-a)/(length(id)-1);
                    radii(id)=a:c:b;
                else
                    radii(id)=a;
                end               
                if length(tmp)==1
                    radii = EstimateRadii(pci, radii, pci(id(end),2), id(end));
                end
            end
            
        end
    end
%-------------------------------------------end of EstimateRadii function


%-------------------------------------------SmoothRadii function
    function radii=SmoothRadii(pci, radii, sn, Aid)
        %smooth the radii vector using moving average
        %pci    -parent-child id
        %radii  -radii vector of the points that form centerline
        %sn     -start node
        %Aid    -Ancestor ids
        %
        
        cid=find(pci(:,1)==sn);  %children id
        
        for k=1:length(cid)
            ind=zeros(1000,1);
            tmp=cid(k);
            co=0;
            while length(tmp)==1
                co=co+1;
                ind(co)=tmp;
                tmp = find(pci(:,1)==pci(tmp,2));
            end
            ind=ind(1:co);
            
            %add ancestor ids
            id = [Aid;ind];
            
            %smooth the vector using moving average
            span=11;    %span of the moving average
            radii(id)=smooth(radii(id),span);
            
            %repeat SmoothRadii with the new branch point (pci(id(end),2))
            if ~isempty(tmp)
                radii=SmoothRadii(pci, radii, pci(id(end),2), ind);
            end
        end
    end
%-------------------------------------------end of SmoothRadii function


end


