function cellinfo = PruneTree(cellinfo)
% This function prunes small branches of the tree
%       
%   input and output: cellinfo (cell information)
%
%
%================================
% Mahmoud Abdolhoseini
% University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
% Oct. 2015 
% Mar. 2016 updated
% Dec. 2016 updated to prune branches that end close to soma
% Sep. 2017 updated to prune the tree automatically
%================================
%


%check if there is a field npci (not pruned pci)
if isfield(cellinfo, 'npci')
    cellinfo.pci=cellinfo.npci;
else
    cellinfo.npci=cellinfo.pci;
end

num = length(cellinfo.pci); %number of cells
mbl=zeros(num,1);
for n=1:num
    pci = cellinfo.pci{n};  %parent-child id

    %estimate minimum branch length (mbl) for pruning
    if isfield(cellinfo.para,'mbl')
        mbl(n)=cellinfo.para.mbl;
    else
        mbl(n)=estMBL(pci);
        temp = PruneShortBranch(pci, mbl(n));
        mbl1=estMBL(temp);
        if mbl1
            temp = PruneShortBranch(pci, mbl1);
            mbl2=estMBL(temp);
            if mbl2
                mbl(n)=mbl1;
                temp = PruneShortBranch(pci, mbl2);
                mbl3=estMBL(temp);
                if mbl3, mbl(n)=mbl2; end
            end
        end
    end
    
    %prune small branches
    while true
        old_pci=pci;
        pci = PruneShortBranch(pci, mbl(n));
        if size(old_pci,1)==size(pci,1); break;end
    end
    
    %prune branches that end close to soma
%     while true
%         old_pci=pci;
%         pci = PruneBCS(cellinfo, pci, n);
%         if size(old_pci,1)==size(pci,1); break;end
%     end
    
    cellinfo.pci{n}=pci;
end
if ~isfield(cellinfo.para, 'mbl'), cellinfo.mbl=mbl; end

%------------------------------------------ estimate MBL (estMBL function)
    function mbl=estMBL(pci)
        % pci   -parent-child id
        % mbl   -minimum branch length
        %
        
        %find endnodes
        endnode=setdiff(pci(:,2), pci(:,1));
        
        dist=zeros(length(endnode),1);
        for k=1:length(endnode)
            id=pci(:,2)==endnode(k);
            dist(k)=dist(k)+pci(id,3);
            p=pci(id,1);
            nc=nnz(pci(:,1)==p);    %number of children
            while nc==1 && p~=1
                id=pci(:,2)==p;
                dist(k)=dist(k)+pci(id,3);
                p=pci(id,1);
                nc=nnz(pci(:,1)==p);
            end
            if p==1, dist(k)=0; end
        end
                
        tmp=nonzeros(dist);
        if isempty(tmp)
            mbl=0;
        else
            mbl=mean(tmp);
        end
        
%         ud=nonzeros(unique(dist));
%         if isempty(ud), mbl=0; return, end
%         tmp=nnz(dist==ud(1));
%         id=1;
%         for k=2:length(ud)
%             no=nnz(dist==ud(k));
%             if no>=tmp, tmp=no; id=k; end
%         end
%         mbl=ud(id);
    end
%------------------------------------------ end of estMBL function


%------------------------------------------ prune short branch
    function pci = PruneShortBranch(pci, mbl, sn)
        % pci   -parent-child id
        % mbl   -minimum branch length
        % sn    -start node
        % n     -cell No
        %
        
        if nargin==2, sn=1; end
        el = pci(pci(:,1)==sn,2:3);
        en = el(:,1);   %end node
        nc = length(en);%number of child
        bl = el(:,2);   %branch length
        bpi = false(nc,1);   %branch point indicator
        
        for m=1:nc
            el = pci(pci(:,1)==en(m),2:3);
            while size(el,1)==1
                en(m) = el(1);
                bl(m) = bl(m)+el(2);
                el = pci(pci(:,1)==en(m),2:3);
            end
            if size(el,1)>1
                bpi(m)=true;
            end
        end
        
        %branch points
        bp=en(bpi);     
        
        id = ~bpi & bl<=mbl;
        if nnz(~id) %if at least one branch will remain after pruning
            pci = prune_it(pci,sn,en(id));
            for co=1:length(bp)
                pci = PruneShortBranch(pci, mbl, bp(co));
            end
        else %if there is nothing left after pruning
            % In this case, keep the longest branch and prune the rest
            [~,I]=max(bl);
            id2 = true(nc,1); id2(I)=false;
            pci = prune_it(pci,sn,en(id2));
        end
    end
%-----------------------------------end of PruneShortBranch function


%-----------------------------------PruneBCS function
    function pci = PruneBCS(cellinfo, pci, n)
        % prune branches that end close to soma
        %
        
        %info
        ce=cellinfo.SomaCentroid(n,:);  %soma centroid in original image
        cec = cellinfo.queue{n}(1,:);   %soma centroid in the cropped area
        stats = regionprops(cellinfo.soma,'PixelList');
        pl = stats(n).PixelList;        %soma pixels in the original image
        
        %find endnodes
        endnode=setdiff(pci(:,2), pci(:,1));
        
        %endnode locations
        enl=cellinfo.queue{n}(endnode,:);
        
        %endnode location in the original image
        enl(:,1)=enl(:,1)+ce(1)-cec(1);
        enl(:,2)=enl(:,2)+ce(2)-cec(2);
        
        %calculate distances of endpoints from soma
        id=false(length(endnode),1);
        if cellinfo.imsize(3)~=1    %3D
            enl(:,3)=enl(:,3)+ce(3)-cec(3);
            for k=1:length(endnode)
                d = sqrt( ((enl(k,1)-pl(:,1))*cellinfo.para.xyRes).^2 + ...
                    ((enl(k,2)-pl(:,2))*cellinfo.para.xyRes).^2 + ...
                    ((enl(k,3)-pl(:,3))*cellinfo.para.zStep).^2);
                [md,ind] = min(d);
                d1= sqrt( ((ce(1)-pl(ind,1))*cellinfo.para.xyRes).^2 + ...
                    ((ce(2)-pl(ind,2))*cellinfo.para.xyRes).^2 + ...
                    ((ce(3)-pl(ind,3))*cellinfo.para.zStep).^2);
                if md<d1, id(k)=true; end
            end
        else    %2D
            for k=1:length(endnode)
                d = sqrt((enl(k,1)-pl(:,1)).^2 + (enl(k,2)-pl(:,2)).^2);
                [md,ind] = min(d);
                d1= sqrt((ce(1)-pl(ind,1)).^2 + (ce(2)-pl(ind,2)).^2);
                if md<d1/5, id(k)=true; end
            end
        end
        
        endnode=endnode(id);
        save_pci=pci;
        for k=1:length(endnode)
            sn=pci(pci(:,2)==endnode(k),1);
            while nnz(pci(:,1)==sn)==1 && sn~=1
                sn = pci(pci(:,2)==sn,1);
            end
            pci=prune_it(pci,sn,endnode(k));
        end
        if isempty(pci), pci=save_pci; end
    end
%----------------------------------------end of pruneBCS function

end



