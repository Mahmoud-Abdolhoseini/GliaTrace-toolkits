function [cellinfo, imarray]=LoadReadPro(cellinfo)
%----->>   Load, Read, and Process images of various type of cells
%
%   usage
%       function [cellinfo, imarray]=LoadReadPro(cellinfo)
%
%   outputs:
%       -cellinfo   cell information
%       -imarray    image arrays
%
%   input:
%       -cellinfo
%   
%
%=================================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% Apr. 2017
% Sep. 2017 Updated to be a general function to consider all type of cells
%=================================


persistent StoredLastFilePathT
persistent StoredLastFilePathS
persistent StoredLastFilePathG
imarray=[];

% trace
if cellinfo.cellPro.trace
    %load images
    if ~isempty(StoredLastFilePathT)
        [filename, filepath] = uigetfile('*.*','Load images for cell tracing','MultiSelect','on',StoredLastFilePathT);
    else
        [filename, filepath] = uigetfile('*.*','Load images for cell tracing','MultiSelect','on');
    end
    if filepath==0, return, end
    StoredLastFilePathT=filepath;
    
    
    if ~iscell(filename)
        filename = {filename};
    end
    
    %store image info
    cellinfo.trace.filename = filename;
    cellinfo.trace.filepath = filepath;
end


% segment
if cellinfo.cellPro.segment
    %load images
    if ~isempty(StoredLastFilePathS)
        [filename, filepath] = uigetfile('*.*','Load images for cell segmentation','MultiSelect','on',StoredLastFilePathS); 
    elseif ~isempty(StoredLastFilePathT)
        [filename, filepath] = uigetfile('*.*','Load images for cell segmentation','MultiSelect','on',StoredLastFilePathT);
    else
        [filename, filepath] = uigetfile('*.*','Load images for cell segmentation','MultiSelect','on');
    end
    if filepath==0, return, end
    StoredLastFilePathS=filepath;
    
    if ~iscell(filename)
        filename = {filename};
    end
    
    %store image info
    cellinfo.segment.filename = filename;
    cellinfo.segment.filepath = filepath;
end


%load ground truths
if 0
    %load images
    if ~isempty(StoredLastFilePathG)
        [filename, filepath] = uigetfile('*.*','Load ground truth images','MultiSelect','on',StoredLastFilePathG);
    elseif ~isempty(StoredLastFilePathT)
        [filename, filepath] = uigetfile('*.*','Load ground truth images','MultiSelect','on',StoredLastFilePathT);
    elseif ~isempty(StoredLastFilePathS)
        [filename, filepath] = uigetfile('*.*','Load ground truth images','MultiSelect','on',StoredLastFilePathS);
    else
        [filename, filepath] = uigetfile('*.*','Load ground truth images','MultiSelect','on');
    end
    if filepath==0, return, end
    StoredLastFilePathG=filepath;
    
    if ~iscell(filename)
        filename = {filename};
    end
    
    %store image info
    cellinfo.segment.filenameGT = filename;
    cellinfo.segment.filepathGT = filepath;
end


%read and process images
if cellinfo.cellPro.trace
    ptf=1;  %process type flag
    tWhole=tic;
    [cellinfo.trace, imarray.trace] = readPro(cellinfo.trace, ptf);
    cellinfo.trace.time.tWhole=toc(tWhole);
end
if cellinfo.cellPro.segment
    ptf=2;
    tWhole=tic;
    [cellinfo.segment, imarray.segment] = readPro(cellinfo.segment, ptf);
    cellinfo.segment.time.tWhole=toc(tWhole);    
end




%inside functions
%------------------------------------------------------->> readPro function
    function [cellinfo, imarray] = readPro(cellinfo, ptf)
        % read and process images
        
        if cellinfo.para.load3Dstack
            imageinfo = imfinfo([cellinfo.filepath,cellinfo.filename{1}]);
            
            % number of slices that each image has (if zl>1, it means the image is a '.tif' stack)
            zl = length(imageinfo);
            
            if zl==1    %if it is not a '.tif' stack
                cellinfo.counter=1;
                
                %read image
                imarray = readAll3D(cellinfo);
                
                %process image
                cellinfo=pro(cellinfo,imarray,ptf);
                
            else    %if it is a '.tif' stack
                saveInfo=cellinfo;
                a=zeros(length(saveInfo.filename),1); p=a; r=a; f=a;
                for n = 1:length(saveInfo.filename)
                    saveInfo.counter=n;
                    imarray = readAll3D(saveInfo);
                    cellinfo= pro(saveInfo,imarray,ptf);
%                     a(n)=cellinfo.a;
%                     p(n)=cellinfo.p;
%                     r(n)=cellinfo.r;
%                     f(n)=cellinfo.f;
                end
%                 cellinfo.a=a;
%                 cellinfo.p=p;
%                 cellinfo.r=r;
%                 cellinfo.f=f;
            end
            
        else %if it is 2D
            saveInfo=cellinfo;
            a=zeros(length(saveInfo.filename),1); p=a; r=a; f=a; j=a;
            for n = 1:length(saveInfo.filename)
                saveInfo.counter=n;
                imageinfo = imfinfo([saveInfo.filepath,saveInfo.filename{saveInfo.counter}]);
                zl = length(imageinfo);
                if zl==1
                    saveInfo.para.load3Dstack=0;    %return it to '0' if 'else' happened in previous loops
                    imarray = readAll2D(saveInfo,imageinfo);
                else
                    saveInfo.para.load3Dstack=1;    %since it is a 3D stack!
                    imarray = readAll3D(saveInfo);
                end
                cellinfo=pro(saveInfo,imarray,ptf);
                
                
%                 a(n)=cellinfo.a;
%                 p(n)=cellinfo.p;
%                 r(n)=cellinfo.r;
%                 f(n)=cellinfo.f;
%                 j(n)=cellinfo.j;
            end
%             cellinfo.a=a;
%             cellinfo.p=p;
%             cellinfo.r=r;
%             cellinfo.f=f;
%             cellinfo.j=j;
        end
    end
%------------------------------------------------>> end of readPro function


%----------------------------------------------------------->> pro function
    function cellinfo=pro(cellinfo,imarray,ptf)
        %cell processing
        
        %trace the cell
        if ptf==1
            cellinfo = traceCell(cellinfo, imarray);
%             figure,imshow(imarray.twoD.colored)
        end
        
        %segment the nucleus
        if ptf==2
%             cellinfo = evaluate_methods(cellinfo, imarray);
            cellinfo = segmentNucleus(cellinfo, imarray);
        end
    end
%---------------------------------------------------->> end of pro function


%----------------------------------------------------->> readAll3D function
    function imarray=readAll3D(cellinfo)
        %read the 3D image
        
        imageinfo = imfinfo([cellinfo.filepath,cellinfo.filename{cellinfo.counter}]);
        zl = length(imageinfo);
        
        if zl==1    %if it is not a '.tif' stack
            numimage=length(cellinfo.filename);
        else
            numimage=zl;
        end
        
        %image class
        tmp=imread([cellinfo.filepath,cellinfo.filename{cellinfo.counter}]);
        cl = class(tmp);
        
        %pre-allocation
        gim3d = true(imageinfo(1).Height, imageinfo(1).Width, numimage);
        gim3d = cast(gim3d, cl);  % change gim3D class to the image class
        imr = gim3d;img = gim3d;imb = gim3d;
        cim3d = true(imageinfo(1).Height, imageinfo(1).Width, 3, numimage);
        cim3d = cast(cim3d, cl);
        for m = 1:numimage
            
            %read each slice
            if zl==1
                [gim3d(:,:,m),coloredslice] = readimage(imageinfo.ColorType, cellinfo.filepath, cellinfo.filename{m});
            else
                [gim3d(:,:,m),coloredslice] = readimage(imageinfo(m).ColorType, cellinfo.filepath, cellinfo.filename{cellinfo.counter}, m);
            end
            cim3d(:,:,:,m)=coloredslice;
            
            if ~isempty(coloredslice)
                imr(:,:,m) = coloredslice(:,:,1);
                img(:,:,m) = coloredslice(:,:,2);
                imb(:,:,m) = coloredslice(:,:,3);
            end
            
            % if IFS, invert the intensity
            if cellinfo.para.IFS
                gim3d(:,:,m) = imadjust(gim3d(:,:,m),[0;1],[1;0]);
            end
        end
        imarray.threeD=gim3d;
        imarray.fourD=cim3d;
        
        [imarray.twoD.gray, ind]=min(gim3d,[],3); %gray MIP image
        
        %change the index
        [r,c]=size(ind);
        tmp=zeros(r,c);
        for k=1:c
            tmp(:,k)=sub2ind([r,c,numimage],(1:r)',k*ones(r,1),ind(1:r,k));
        end
        
        if ~isempty(coloredslice)
            miprgb(:,:,1) = imr(tmp);
            miprgb(:,:,2) = img(tmp);
            miprgb(:,:,3) = imb(tmp);
            imarray.twoD.colored=miprgb; %colored MIP image
        end   
    end
%---------------------------------------------->> End of readAll3D function


%----------------------------------------------------->> readAll2D function
    function imarray=readAll2D(cellinfo,imageinfo)
        
        [imarray.twoD.gray, cim2d] = readimage(imageinfo.ColorType, cellinfo.filepath, cellinfo.filename{cellinfo.counter});
        if ~isempty(cim2d)
            imarray.twoD.colored = cim2d;
        end
        if cellinfo.para.IFS
            imarray.twoD.gray = imadjust(imarray.twoD.gray,[0;1],[1;0]);
        end
        
    end
%---------------------------------------------->> End of readAll2D function



%----------------------------------------------------->> readimage function
    function [img,imc] = readimage(ColorType, filepath, filename, m)
        % img   -image grayscale
        % imc   -image colored
        if nargin==3
            switch ColorType
                case 'grayscale'
                    img = imread([filepath,filename]);
                    imc = [];
                case 'truecolor'
                    imc = imread([filepath,filename]);
                    img = rgb2gray(imc);
                case 'indexed'
                    [X,map] = imread([filepath,filename]);
                    imc = ind2rgb(X,map);
                    img = ind2gray(X,map);
                otherwise
                    error('Image type must be: grayscale, or truecolor, or indexed')
            end
        elseif nargin==4
            switch ColorType
                case 'grayscale'
                    img = imread([filepath,filename],m);
                    imc = [];
                case 'truecolor'
                    imc = imread([filepath,filename],m);
                    img = rgb2gray(imc);
                case 'indexed'
                    [X,map] = imread([filepath,filename],m);
                    imc = ind2rgb(X,map);
                    img = ind2gray(X,map);
                otherwise
                    error('Image type must be: grayscale, or truecolor, or indexed')
            end
        end
    end
%---------------------------------------------->> End of readimage function

end
