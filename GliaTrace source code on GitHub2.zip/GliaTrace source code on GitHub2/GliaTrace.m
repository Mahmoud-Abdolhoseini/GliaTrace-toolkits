function [cellinfo, imarray] = GliaTrace(cellinfo, imarray)
%----->>   Cell Tracing and Segmentation
%   inputs and outputs:
%       -cellinfo   cell information
%       -imarray    image arrays   
%
%
%
%==============================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% Apr. 2016
% Apr. 2017 updated to segment the nucleus
%==============================


%- Parameters (set these if GliaTrace is called with no input to the function) 

%choose the desired processing
cellPro.trace=1;    %'1' if you want to trace cells, '0' otherwise.
cellPro.segment=0;  %'1' if you want to segment cells, '0' otherwise.




%for tracing
paraT.IFS = 1;
%'1' if Intensity of Foreground Signal (IFS) is higher than background, '0' otherwise.
%note: typically a fluorescent image will have IFS = 1, while a brightfield image will have IFS=0.
paraT.minObj= 0;     %minimum object area to be considered, set '0' for automatic calculation
paraT.load3Dstack = 1;  %'1' if loading 3D stack, '0' otherwise.
paraT.threeD = 0;       %'1' for 3D tracing, '0' for 2D tracing (in case of loading a 3D stack, its MIP is used for 2D tracing).
paraT.SomaLevel=0;      %choose a threshold (between 1-20) to segment soma, leave it '0' for automatic calculation
paraT.BackgroundLevel=0;%choose a threshold (between 1-20) to remove background, leave it '0' for automatic calculation
paraT.xyRes = 0.271;      %x-y resolution (micrometer/pixel)
paraT.zStep = 1;        %z-step size (micrometer)



%for segmentation
paraS.IFS = 1;
paraS.minObj=50;
paraS.load3Dstack = 1;  %'1' if loading 3D stack, '0' otherwise.
paraS.threeD = 0;       %'1' for 3D segmentation, '0' for 2D segmentation
%---------------------------------------------------------end of parameters


                        





% store parameters into cellinfo structure
if nargin==0
    
    cellinfo.cellPro = cellPro;
    
    %trace
    if cellPro.trace
        cellinfo.trace.para = paraT;
    end
    
    %segment
    if cellPro.segment
        cellinfo.segment.para = paraS;
    end

     
    %default para for tracing
    if cellPro.trace
        if paraT.IFS
            cellinfo.trace.para.SomaRadius = 2.2;   %mu
        else
            cellinfo.trace.para.SomaRadius = 2.3;   %mu
        end
        cellinfo.trace.para.MaxCellRadius = 30; %mu
        cellinfo.trace.para.mbl=7; %mu, minimum branch length for pruning
        cellinfo.trace.para.spreadsheet = 1;
        cellinfo.trace.para.remove_cell_intouchwith_border = 0;
        cellinfo.trace.para.smoothit = 0;
        cellinfo.trace.para.swcfile = 1;
    end
end

% Load, Read, and Process images of various types of cells
if nargin<2
    [cellinfo, imarray]=LoadReadPro(cellinfo);
end

%if both cellinfo and imarray exist, run the process
if nargin==2
    if cellinfo.cellPro.trace
        cellinfo.trace = traceCell(cellinfo.trace, imarray.trace);
    end
    if cellinfo.cellPro.segment
        cellinfo.segment = segmentNucleus(cellinfo.segment, imarray.segment);
    end
end



if cellinfo.cellPro.trace && isfield(cellinfo.trace,'soma')
    %check if any cell is found
    if isempty(cellinfo.trace.soma)
        warning('No cell has been found!!');
        disp('Please reduce minObj parameter.')
        disp('Or increase xyRes if you chose ''0'' for minObj.')
        return
    end
    if isempty(cellinfo.trace.SomaCentroid)
        warning('No cell has been found!!');
        disp('Please set remove_cell_intouchwith_border to ''0''.')
        return
    end
end



