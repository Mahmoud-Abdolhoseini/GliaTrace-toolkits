function sam = min_win(image, nump, mask)
%----->> Sampling the mask area
%
% sam = min_win(image, win, mask)
%
% inputs:
%       image
%       nump        - nump determines the sampling rate
%       mask        - the area that we want to sample
%
% output:
%       sam         - sampled level, same size as image
%
%==============================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
% Nov., 2015
% May,  2016    upgraded to 3D
%==============================


image = double(image);
[yl, xl, zl] = size(image);

% if there is mask, put Inf in image pixels where mask==0
if nargin==3
    mask = double(mask);
    mask(mask==0) = Inf;
    image = image + mask;
end

% ranges
nwx = floor(xl/nump);
rx  = xl - nump*nwx;
xr = [(0:nwx-1)*nump + 1; (1:nwx)*nump];
if rx; xr = [xr, [xr(end)+1; xr(end)+rx]]; nwx=nwx+1; end
nwy = floor(yl/nump);
ry = yl - nump*nwy;
yr = [(0:nwy-1)*nump + 1; (1:nwy)*nump];
if ry; yr = [yr, [yr(end)+1; yr(end)+ry]]; nwy=nwy+1; end


% select the node with minimum intensity in each cropped area
sam=false(yl, xl, zl);
for n=1:zl
    for xi=1:nwx
        for yi=1:nwy
            x=image(yr(1,yi):yr(2,yi),xr(1,xi):xr(2,xi),n);
            [va,id] = min(x(:));
            if va==Inf, continue, end
            x(:)=0;
            x(id)=1;
            sam(yr(1,yi):yr(2,yi),xr(1,xi):xr(2,xi),n)=x;
        end
    end
end




