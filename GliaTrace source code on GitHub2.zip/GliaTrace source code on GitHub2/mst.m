function cellinfo = mst(cellinfo, BW)
%
%----- Minimum Spanning Tree (MST)
%           -Save all the parent-child Ids (pci) and their distance
%
%   cellinfo = MinSpanTree(cellinfo, BW)
%
%   inputs
%           cellinfo    -cell information
%           BW          -bw area
%
%   output
%           cellinfo    -cell information
%
%==============================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% May, 2016
% Nov. 2016  updated(start tracing from the centroid of the soma)
%==============================

Idm = find(~cellfun(@isempty, cellinfo.queue), 1, 'Last');
queue = cellinfo.queue{Idm};
nsp = cellinfo.nsp{Idm};
lq  = length(queue);
nlc = length(nsp);
p = 4; % pick p number of nodes in each level

%initialization
pci = zeros(lq,3);  % to save all the [parent_id, child_id, distance]
cid = zeros(lq,1);  % connected node id
pci(1:nsp(1)-1,:)=[ones(nsp(1)-1,1), [2:nsp(1)]', zeros(nsp(1)-1,1)];
cid(1:nsp(1))=1:nsp(1);

geo_mat = zeros(p,lq,nlc); % to store all geodesic distances
geo_mat(:,1,:)=Inf;
node_id = zeros(p,lq,nlc); % to store id of all the nodes
for n=2:nsp(1)
    [D, nid]=distcal(cellinfo, cid(1:nsp(1)), n, BW);
    geo_mat(:,n,:)=D;
    node_id(:,n,:)=nid;
end

counter = nsp(1);
le = 1;
% BW = BW2;
while true
    if le <= 2 %|| le==nlc
        temp = geo_mat(:,1:counter,le);
        [val, ind] = min(temp(:));
        [d1, d2] = ind2sub([p,counter],ind);
        d3 = le;
    else
        temp = geo_mat(:,1:save_id,le);
        [val, ind] = min(temp(:));
        [d1, d2] = ind2sub([p,save_id],ind);
        d3 = le;
        
        temp = geo_mat(:,save_id+1:counter,2:le);
        [val2, ind] = min(temp(:));
        if val2 < val
            val = val2;
            [d1, d2, d3] = ind2sub([p,counter-save_id,le-1],ind);
            d2 = d2 + save_id;
            d3 = d3 + 1;
        end
    end
    
    if val==Inf
        if le == nlc; break; end
        le = le + 1;
        save_id = counter;
%         if le == nlc-1; BW = BW1; end
        continue
    end
    
    cid(counter+1) = node_id(d1, d2, d3);
    pci(counter,:)  = [cid(d2), cid(counter+1), val];
    
    %-----> update geo_mat
    ind = node_id(:,1:counter,d3) == cid(counter+1);
    temp = geo_mat(:,1:counter,d3);
    temp(ind) = Inf;
    geo_mat(:,1:counter,d3) = temp;
    %-----
    
    [D, nid] = distcal(cellinfo, cid(1:counter+1), cid(counter+1), BW);
    counter = counter + 1;
    geo_mat(:,counter,:) = D;
    node_id(:,counter,:) = nid;
end
cellinfo.pci{Idm} = pci(1:counter-1,:);




