function cellinfo = segmentNucleus(cellinfo, imarray)


mss = cellinfo.para.minObj;
if cellinfo.para.load3Dstack && cellinfo.para.threeD
    image = imarray.threeD;
else
    image = imarray.twoD.gray;
end
if size(image,3)==1
    ThreeD=false;
else
    ThreeD=true;
end


%background correction/gaussian smoothing
image=background_correction(image);

%global threshold
bw=image<=multithresh(image);
% bw=bwareaopen(bw,mss);

%local threshold on watershed regions
if ~ThreeD
    bw=local_thresh(bw,image);
end
% figure,imshow(bw)
% figure,imshow(label2rgb(labelmatrix(bwconncomp(bw)),'jet','w','shuffle'))

%***fill small holes
if mss>500
    holes=imfill(bw,'holes') & (~bw);
    Obj=regionprops(holes,'Area','PixelIdxList');
    Ar=[Obj.Area];
    Ind=Ar<mean(Ar);
    bw(cat(1,Obj(Ind).PixelIdxList))=true;
end

%split cluster cells
bw=split_cluster_cell(bw,image);
% figure,imshow(bw)
% figure,imshow(label2rgb(labelmatrix(bwconncomp(bw)),'jet','w','shuffle'))

%merge wrong split objects based on cell model
if ~ThreeD
    bw=merge_obj(bw);
end
% figure,imshow(bw)
% figure,imshow(label2rgb(labelmatrix(bwconncomp(bw)),'jet','w','shuffle'))

%final correction based on cell model
bw=model_based_correction(bw,image);

%save segmentation results
bw=imfill(bw,'holes');
cellinfo.segmentedCells=bw;
cellinfo=saveResults(cellinfo, imarray);
% figure,imshow(bw)
% figure,imshow(label2rgb(labelmatrix(bwconncomp(bw)),'jet','w','shuffle'))


%----------inside functions
%
%--------------------------------------------------------------------------
    function image=background_correction(image)
        flag_double=false;
        if ~isa(image,'uint8')
            if isa(image,'double'), flag_double=true; end
            image=im2uint8(image);
        end
        
        h=imhist(image);
        h(h<0.005*max(h))=0;
        idf=find(h,1,'first');
        idl=find(h,1,'last');
        B=idl-idf+1;
        half=ceil(B/2)+idf;
        if B>150
            h(1:(half-ceil(B/10)))=0;
            tmp=0;
            while ~isequal(h,tmp)
                tmp=h;
                [~,I]=sort(h,'descend');
                d=I-[I(2:end);0];
                id=find(d<0)+1;
                h(I(id))=0;
            end
            ind=find(I<(half+ceil(B/10)),1,'first');
            if ind==1, return, end
            d=[idl-I(1);d];
            [~,id]=max(d(1:ind-1));
            mask=I(id)-1;
%             figure,imhist(image)
            image(image>mask)=mask;
        else
            image=imgaussfilt(image,2);
        end
%         hold on 
%         plot(mask,h(mask+1),'or')
%         hold off
        
        if flag_double, image=im2double(image); end
    end
%----------------------------------------------end of background_correction
%
%
%--------------------------------------------------------------------------
    function bw=local_thresh(bw,image)
        
        imSize=size(image);
        R=watershed(~bw);
        num=max(R(:));
        r=zeros(num,6);
        for n=1:num
            id=find(R==n);
            [ro,c,z]=ind2sub(imSize,id);
            r(n,1)=min(ro);  r(n,2)=max(ro);
            r(n,3)=min(c);  r(n,4)=max(c);
            r(n,5)=min(z);  r(n,6)=max(z);
            
            imq=false(imSize);
            imq(id)=bw(id);
            tmp1=imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6));
            prop1=regionprops(tmp1,'Area');
            if prop1.Area<mss/10, continue, end
            
            imq(id)=image(id)<=multithresh(image(id));
            tmp2=imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6));
            prop2=regionprops(tmp2,'PixelIdxList','Solidity');
            if prop1.Area<mss
                ind=[prop2.Solidity]<0.9;
                if nnz(ind), tmp2(cat(1,prop2(ind).PixelIdxList))=false; end
            end
            
            imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6))=tmp2;
            bw(id)=imq(id);
        end
    end
%-------------------------------------------------------end of local_thresh
%
%
%--------------------------------------------------------------------------
    function bw=split_cluster_cell(bw,image)
        imSize=size(image);
        obj=regionprops(bw,'Area','PixelIdxList');
        A=[obj.Area];
        idx=find(A>mss);
        con=false(imSize);
        for n=idx
            id=obj(n).PixelIdxList;
            [ro,c,z]=ind2sub(imSize,id);
            r(1)=min(ro);  r(2)=max(ro);
            r(3)=min(c);  r(4)=max(c);
            r(5)=min(z);  r(6)=max(z);
            
            imq=false(imSize);
            imq(id)=true;
            bwc=imq(r(1):r(2), r(3):r(4), r(5):r(6));
            im=double(image(r(1):r(2), r(3):r(4), r(5):r(6)));
%             imc=imarray.twoD.colored(r(1):r(2), r(3):r(4), :);
%             figure,imshow(imc)
            
            %distance map
            distMap=bwdist(~bwc);

            %scale the distmap and im to [0 1]
            ind=find(bwc);
            a=min(distMap(ind)); b=max(distMap(ind));
            if a~=b
                distMap=(distMap-a)/(b-a);
            else
                distMap=distMap/a;
            end
            a=min(im(ind)); b=max(im(ind));
            if a~=b
                imn=(im-a)/(b-a);
            else
                imn=im/a;
            end
            
            
            %incorporating distance map into the intensity
            imd=imn-distMap;
%             figure,imshow(min(imn,[],3),[])
%             figure,imshow(max(bwc,[],3))
%             figure,imshow(min(-distMap,[],3),[])
%             figure,imshow(min(imd,[],3),[])

%             bwc(~watershed(imd))=false;
%             figure,imshow(label2rgb(labelmatrix(bwconncomp(bwc))))
            
            %break object based on topographical map and watershed
            bwc=breakObj(bwc,ind,imd);
%             figure,imshow(label2rgb(labelmatrix(bwconncomp(bwc))))
            
            if isempty(bwc), continue, end
            
            %recursively break any remaining big objects
            if obj(n).Area>10*mss
                bwc=split_cluster_cell(bwc,im);
            end
            
            con(r(1):r(2), r(3):r(4), r(5):r(6))=bwc;
            bw(id)=con(id);
        end
    end
%-------------------------------------------------end of split_cluster_cell
%
% 
%--------------------------------------------------------------------------
    function bwc=breakObj(bwc,id,im)
        numOfThresh=floor(length(id)/mss);
        numOfThresh(numOfThresh>20)=20;
        if numOfThresh==0, bwc=[]; return, end
        map=ones(size(im))*(numOfThresh+2);
        map(id)=imquantize(im(id),multithresh(im(id),numOfThresh));
        
        for n=1:numOfThresh
            L=map==n;
            prop=regionprops(L,'Area','PixelIdxList');
            A=[prop.Area];
            idx=A<(n*mss)/(numOfThresh+1);
            ind=cat(1,prop(idx).PixelIdxList);
            map(ind)=n+1;
        end
%         figure,imshow(min(map,[],3),[])
        
        %watershed
        cb=~watershed(map);
        if nnz(cb)
            bwc(cb)=false;
        else
            bwc=[];
        end
    end
%-----------------------------------------------------------end of breakObj
%
%
%--------------------------------------------------------------------------
    function bw=merge_obj(bw)
        imSize=size(bw);
        
        %limit the target to the possibly wrong split objects
        obj=regionprops(bw,'PixelList','PixelIdxList','Area','Solidity');
        Maxss=10*mss;
        id=(mss/10)<[obj.Area] & [obj.Area]<Maxss;
        id=find(id);
        
        %make a label matrix of objects
        LM=zeros(imSize);
        for n=1:length(obj), LM(obj(n).PixelIdxList)=n; end
        
        fixed_id=id;
        for n=fixed_id
            if ~nnz(n==id), continue, end
            pl=obj(n).PixelList;
            [border_id,cross_id]=find_neighbours(pl,imSize);
            LM_val=LM(sub2ind(imSize,cross_id(:,1),cross_id(:,2)));
            obj_id=nonzeros(unique(LM_val));
            target_id=intersect(obj_id,id);
            le=length(target_id);
            
            %check if there is a better possibility :)
            if le==1
                [~,c_id]=find_neighbours(obj(target_id).PixelList,imSize);
                val=LM(sub2ind(imSize,c_id(:,1),c_id(:,2)));
                obj_id=nonzeros(unique(val));
                if length(intersect(obj_id,id))>1, continue, end
            end
            
            %remove the object id from the list
            id=id(id~=n);
            
            if le==0, continue, end
            
            %individual and merged solidities
            I_Sol=zeros(le,1);   %individual solidity
            neck_id=cell(le,1);
            M_Sol=zeros(le,1);     %merged solidity
            for k=1:le
                tk=target_id(k);
                I_Sol(k)=obj(tk).Solidity;
                id_k=cross_id(LM_val==tk,:);
                x=id_k(:,2); y=id_k(:,1);
                n_id=[y-1,x-1;y-1,x;y-1,x+1;y,x-1;y,x+1;y+1,x-1;y+1,x;y+1,x+1];
                n_id=intersect(n_id,border_id,'rows');
                n_id=remove_last_pixels(n_id,LM,n,tk);                
                neck_id{k}=sub2ind(imSize,n_id(:,1),n_id(:,2));
                M=false(imSize);
                M(cat(1,obj(tk).PixelIdxList))=true;
                M(cat(1,obj(n).PixelIdxList))=true;
                M(neck_id{k})=true;
                M=imfill(M,'holes');
                prop=regionprops(M,'Area','Solidity');
                if prop.Area<Maxss && prop.Solidity>mean([obj(n).Solidity,obj(tk).Solidity])
                    M_Sol(k)=prop.Solidity;
                end
            end
            
            
            %compare solidity of merging all objects to the average solidity of individuals
            if le>1
                M=false(imSize);
                M(cat(1,obj(target_id).PixelIdxList))=true;
                M(cat(1,obj(n).PixelIdxList))=true;
                n_id=cat(1,neck_id{:});
                M(n_id)=true;
                prop=regionprops(M,'Area','Solidity');
                if prop.Area<Maxss && prop.Solidity>mean([obj(n).Solidity;I_Sol])
                    bw(n_id)=true;
                    id=setdiff(id,target_id);
                    continue
                end
            end
            
            %the biggest pair solidity
            [val,I]=max(M_Sol);
            if val
                bw(neck_id{I})=true;
                id=id(id~=target_id(I));
            end
        end
    end
%----------------------------------------------------------end of merge_obj
%
%
%--------------------------------------------------------------------------
    function [border_id,cross_id]=find_neighbours(pl,imSize)
        x=pl(:,1); y=pl(:,2);
        ind=[y-1,x-1;y-1,x;y-1,x+1;y,x-1;y,x+1;y+1,x-1;y+1,x;y+1,x+1];
%         ind=[y-1,x;y+1,x;y,x-1;y,x+1];
        b_id=setdiff(ind,[y,x],'rows');
        idx=b_id(:,1)<1 | b_id(:,2)<1 | b_id(:,1)>imSize(1) | b_id(:,2)>imSize(2);
        border_id=b_id(~idx,:);
        if nargout==1, return, end
        x=border_id(:,2); y=border_id(:,1);
        ind=[y-1,x;y+1,x;y,x-1;y,x+1];
        c_id=setdiff(ind,[y,x;pl(:,2),pl(:,1)],'rows');
        idx=c_id(:,1)<1 | c_id(:,2)<1 | c_id(:,1)>imSize(1) | c_id(:,2)>imSize(2);
        cross_id=c_id(~idx,:);
    end
%----------------------------------------------------end of find_neighbours
%
%
%--------------------------------------------------------------------------
    function id=remove_last_pixels(id,LM,a,b)
        
        if size(id,1)<=2, return, end
        imSize=size(LM);
        ind(:,1)=id(:,1)==min(id(:,1));
        ind(:,2)=id(:,1)==max(id(:,1));
        ind(:,3)=id(:,2)==max(id(:,2));
        ind(:,4)=id(:,2)==min(id(:,2));
        
        %remove pixels connected to other borders
        m=ind(:,1)|ind(:,2)|ind(:,3)|ind(:,4);  %margin
        nm=find(m);
        for k=1:length(nm)
            y=id(nm(k),1); x=id(nm(k),2);
            if y==1 || x==1 || y==imSize(1) || x==imSize(2), continue, end
            I=[y-1,x-1;y-1,x;y-1,x+1;y,x-1;y,x+1;y+1,x-1;y+1,x;y+1,x+1];
            tmp=LM(sub2ind(imSize,I(:,1),I(:,2)));
            tmp2= tmp==0 | tmp==a | tmp==b;
            if nnz(tmp2==0), id(nm(k),1)=0; end
        end
        
        %remove end pixels
        I=find(sum(ind)==1);
        for k=I
            id(ind(:,k),1)=0;
        end
        
        %update id
        id=id(logical(id(:,1)),:);
    end
%-------------------------------------------------end of remove_last_pixels
%
%
%--------------------------------------------------------------------------
    function bw=model_based_correction(bw,image)
        
        if size(image,3)~=1, bw=bwareaopen(bw,mss); return, end
        bw=bwareaopen(bw,round(mss/2));
        imSize=size(image);
        R=watershed(~bw);
        num=max(R(:));
        r=zeros(num,6);
        for n=1:num
            id=find(R==n);
            [ro,c,z]=ind2sub(imSize,id);
            r(n,1)=min(ro);  r(n,2)=max(ro);
            r(n,3)=min(c);  r(n,4)=max(c);
            r(n,5)=min(z);  r(n,6)=max(z);
            
            imq=false(imSize);
            imq(id)=bw(id);
            tmp1=imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6));
            prop1=regionprops(tmp1,'Area','PixelIdxList','Solidity');
            
            imq(id)=image(id)<=multithresh(image(id));
            tmp2=imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6));
            prop2=regionprops(tmp2,'Area','PixelIdxList','Solidity');
            prop2=prop2([prop2.Area]>=mss);
            
            tmp=false(size(tmp1));
            if ~isempty(prop2)
                [~,I]=max([prop2.Area]);
                if prop2(I).Solidity>prop1.Solidity
                    tmp(prop2(I).PixelIdxList)=true;
                elseif prop1.Area>=mss
                    tmp(prop1.PixelIdxList)=true;
                end
                ind=[prop2.Solidity]>0.8;
                ind(I)=false;
                tmp(cat(1,prop2(ind).PixelIdxList))=true;
            elseif prop1.Area>=mss
                tmp(prop1.PixelIdxList)=true;
            end
            
            imq(r(n,1):r(n,2), r(n,3):r(n,4), r(n,5):r(n,6))=tmp;
            bw(id)=imq(id);
        end
    end
%---------------------------------------------end of model_based_correction
%
%
%--------------------------------------------------------------------------
    function cellinfo=saveResults(cellinfo,imarray)
        
        bwl=cellinfo.segmentedCells;    %bw local
        imSize=size(bwl);
        if length(imSize)==3
            threeD=true;
        else
            threeD=false;
        end
        
        % make a result folder to store results
        if ~exist([cellinfo.filepath,'results'],'dir')
            mkdir(cellinfo.filepath,'results')
        end
        filepath=[cellinfo.filepath,'results\'];
        [~,name] = fileparts(cellinfo.filename{cellinfo.counter});
        if threeD
            name=[name,'_3D'];
        else
            name=[name,'_2D'];
        end
        
        
        figure,imshow(label2rgb(max(labelmatrix(bwconncomp(bwl)),[],3),'jet','w','shuffle'))
        saveas(gca, [filepath,num2str(cellinfo.counter),'_seg_',name], 'png')
%         saveas(gca, [filepath,num2str(cellinfo.counter),'_seg3D_',num2str(cellinfo.para.minObj),'minObj'], 'epsc')
%         figure,imshow(imarray.twoD.gray)
%         figure,imshow(imarray.twoD.colored)
%         saveas(gca, [filepath,num2str(cellinfo.counter),'_im'], 'epsc')
        
        
        
        %save object info
        obj=regionprops(bwl,'Area','Centroid');
        num_cell=length(obj);
        ce=cat(1,obj.Centroid);
        cellinfo.result.CellNo=(1:num_cell)';
        cellinfo.result.Centroid_x=round(ce(:,1),2);
        cellinfo.result.Centroid_y=round(ce(:,2),2);
        if threeD, cellinfo.result.Centroid_z=round(ce(:,3),2); end
        cellinfo.result.Area=[obj.Area]';
        cellQtable = struct2table(cellinfo.result);
        
        % write the results in Excel spreadsheet
        if threeD
            sizeString=[num2str(imSize(1)),' * ',num2str(imSize(2)),' * ',num2str(imSize(3))];
        else
            sizeString=[num2str(imSize(1)),' * ',num2str(imSize(2))];
        end
        if exist([filepath,name,'.xlsx'],'file')
            delete([filepath,name,'.xlsx']);
        end
        xlswrite([filepath,name,'.xlsx'], {'Info','Name','Size (pixel)','minObj'},1,'A1')
        xlswrite([filepath,name,'.xlsx'], {'Segmented by', 'Date'},1,'F1')
        xlswrite([filepath,name,'.xlsx'], {name,sizeString,mss},1,'B2')
        xlswrite([filepath,name,'.xlsx'], {'GliaTrace programmed by Mahmoud Abdolhoseini, mahmoud.abdolhoseini@uon.edu.au', datestr(datetime('now'))},1,'F2')
        xlswrite([filepath,name,'.xlsx'], {'Number of cells found',num2str(num_cell)},1,'A5')
        writetable(cellQtable,[filepath,name,'.xlsx'],'Range','A7')
        
        
    end
%------------------------------------------------------------end of topoMap








end