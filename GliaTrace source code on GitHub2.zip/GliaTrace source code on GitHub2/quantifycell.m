function cellinfo = quantifycell(cellinfo)
%
%----->>  quantify cell (soma, branches and cell body)
%
%
%   cellinfo = quantifycell(cellinfo, nn)
%
%   cellinfo    -cell information
%   nn          -number of file
%
%
%==============================
% Apr. 2016
% Dec. 2016 updated (to consider new volume and area calculated using
%                       cellinfo.radii in quantifyBranch function)
% Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
%==============================




%cellinfo
xyRes = cellinfo.para.xyRes;
num_cell = size(cellinfo.pci,1);
cellinfo.cellQ.CellNo=(1:num_cell)';

% image info
yl = cellinfo.imsize(1);
xl = cellinfo.imsize(2);
zl = cellinfo.imsize(3);

% check if it is threeD
if zl==1
    threeD=0;
else
    threeD=1;
    zStep  = cellinfo.para.zStep;
end

% pre-allocation and display order of quantification info in spreadsheet
cellinfo.cellQ.NumPrimaryBranch = zeros(num_cell,1);
cellinfo.cellQ.TotalNumBranchPoint = zeros(num_cell,1);
cellinfo.cellQ.TotalBranchLength = zeros(num_cell,1);
cellinfo.cellQ.CellRadius=zeros(num_cell,1);    
if threeD
    cellinfo.cellQ.SomaVolume=0;
    cellinfo.cellQ.CellVolume=zeros(num_cell,1);
else
    cellinfo.cellQ.SomaArea=0;
    cellinfo.cellQ.SomaEccentricity=0;
    cellinfo.cellQ.CellArea=zeros(num_cell,1);
    cellinfo.cellQ.CellSolidity=zeros(num_cell,1);
    cellinfo.cellQ.CellExtent=zeros(num_cell,1);
end


%SomaArea/Volume, SomaEccentricity
if threeD
    stats = regionprops(cellinfo.soma, 'Area', 'PixelIdxList');
    cellinfo.cellQ.SomaVolume = [stats.Area]' *(xyRes^2)*zStep;
else
    stats = regionprops(cellinfo.soma, 'Area', 'PixelIdxList', 'Eccentricity');
    cellinfo.cellQ.SomaArea = [stats.Area]' *(xyRes^2);
    cellinfo.cellQ.SomaEccentricity = [stats.Eccentricity]';
end


%NumPrimaryBranch, TotalNumBranchPoint, TotalBranchLength, CellArea/Volume
cellinfo = quantifyBranch(cellinfo);


%CellRadius, Solidity and Extent
for n=1:num_cell
    
    pci = cellinfo.pci{n};  %parent-child id
    if isempty(pci), continue, end
    
    %find endnodes
    endnode=setdiff(pci(:,2), pci(:,1));
    
    %endnode locations
    enl=cellinfo.queue{n}(endnode,:);
    
    %soma centroid
    cec = cellinfo.queue{n}(1,:);   
    
    %find the furthest distance
    if threeD
        dist=max(sqrt( ((cec(1)-enl(:,1))*xyRes).^2 + ...
            ((cec(2)-enl(:,2))*xyRes).^2 + ((cec(3)-enl(:,3))*zStep).^2 ));
    else
        dist=max(sqrt( ((cec(1)-enl(:,1))*xyRes).^2 + ...
            ((cec(2)-enl(:,2))*xyRes).^2 ));
    end
    
    %store the furthest distance from the soma centroid as the cell radius
    cellinfo.cellQ.CellRadius(n)=dist;
    
    %if 2D, calculate cell solidity and extent
    if ~threeD
        centerline=zeros(yl, xl);
        ce = cellinfo.SomaCentroid(n,:);  %centroid position in global image
        px = ce(1)-cec(1) + cellinfo.queue{n}(pci(:,1),1);
        py = ce(2)-cec(2) + cellinfo.queue{n}(pci(:,1),2);
        cx = ce(1)-cec(1) + cellinfo.queue{n}(pci(:,2),1);
        cy = ce(2)-cec(2) + cellinfo.queue{n}(pci(:,2),2);
        p = [px,py];    %parent
        c = [cx,cy];    %children
        for m = 1:size(pci,1)
            centerline = func_Drawline(centerline, p(m,2),p(m,1),c(m,2),c(m,1), 1);
        end
        
        %soma array
        s =false(yl,xl);
        s(stats(n).PixelIdxList)=true;
        
        %centerline plus soma array
        cps = centerline(1:yl,1:xl) | s;
        
        %cell solidity and extent
        Q = regionprops(cps, 'BoundingBox', 'ConvexArea');
        cellinfo.cellQ.CellSolidity(n) = cellinfo.cellQ.CellArea(n)/Q.ConvexArea;
        cellinfo.cellQ.CellExtent(n)   = cellinfo.cellQ.CellArea(n)/(Q.BoundingBox(3)*Q.BoundingBox(4));
        
    end
end


% make a table
cellQtable = struct2table(cellinfo.cellQ);

% file info
[~,name,~] = fileparts(cellinfo.filename{cellinfo.counter});

% make a result folder to store results
if ~exist([cellinfo.filepath,'results'],'dir')
    mkdir(cellinfo.filepath,'results')
end
filepath=[cellinfo.filepath,'results\'];

% Delete the old table and write a new one in a spreadsheet
if threeD
    if exist([filepath,name,'_3D.xlsx'],'file')
        delete([filepath,name,'_3D.xlsx']);
    end
    xlswrite([filepath,name,'_3D.xlsx'], {'Info','Name','x-y Resolution (um/pixel)'},1,'A1')
    xlswrite([filepath,name,'_3D.xlsx'], {'z-step Size (um)','Size (voxel)'},1,'D1')
    xlswrite([filepath,name,'_3D.xlsx'], {'minObj','SomaLevel','BackgroundLevel'},1,'F1')
    xlswrite([filepath,name,'_3D.xlsx'], {'Run Time (seconds), soma and bg level', 'Run Time (seconds), main process', 'Run Time (seconds), pruning'},1,'I1')
    xlswrite([filepath,name,'_3D.xlsx'], {'Reconstructed by', 'Date'},1,'L1')
    xlswrite([filepath,name,'_3D.xlsx'], {name,num2str(cellinfo.para.xyRes)},1,'B2')
    xlswrite([filepath,name,'_3D.xlsx'], {num2str(cellinfo.para.zStep),[num2str(yl),' * ',num2str(xl),' * ',num2str(zl)]},1,'D2')
    xlswrite([filepath,name,'_3D.xlsx'], {num2str(cellinfo.mss),num2str(cellinfo.SomaLevel),num2str(cellinfo.BackgroundLevel)},1,'F2')
    xlswrite([filepath,name,'_3D.xlsx'], {num2str(cellinfo.time.tSoma), num2str(cellinfo.time.tMain), num2str(cellinfo.time.tPrune)},1,'I2')
    xlswrite([filepath,name,'_3D.xlsx'], {'GliaTrace programmed by Mahmoud Abdolhoseini, mahmoud.abdolhoseini@uon.edu.au', datestr(datetime('now'))},1,'L2')
    writetable(cellQtable,[filepath,name,'_3D.xlsx'],'Range','A5')
else
    if exist([filepath,name,'_2D.xlsx'],'file')
        delete([filepath,name,'_2D.xlsx']);
    end
    xlswrite([filepath,name,'_2D.xlsx'], {'Info','Name','x-y Resolution (um/pixel)'},1,'A1')
    xlswrite([filepath,name,'_2D.xlsx'], {'Size (pixel)'},1,'D1')
    xlswrite([filepath,name,'_2D.xlsx'], {'minObj','SomaLevel','BackgroundLevel'},1,'E1')
    xlswrite([filepath,name,'_2D.xlsx'], {'Run Time (seconds), soma and bg level', 'Run Time (seconds), main process', 'Run Time (seconds), pruning'},1,'H1')
    xlswrite([filepath,name,'_2D.xlsx'], {'Reconstructed by', 'Date'},1,'K1')
    xlswrite([filepath,name,'_2D.xlsx'], {name,num2str(cellinfo.para.xyRes)},1,'B2')
    xlswrite([filepath,name,'_2D.xlsx'], {[num2str(yl),' * ',num2str(xl)]},1,'D2')
    xlswrite([filepath,name,'_2D.xlsx'], {num2str(cellinfo.mss),num2str(cellinfo.SomaLevel),num2str(cellinfo.BackgroundLevel)},1,'E2')
    xlswrite([filepath,name,'_2D.xlsx'], {num2str(cellinfo.time.tSoma), num2str(cellinfo.time.tMain), num2str(cellinfo.time.tPrune)},1,'H2')
    xlswrite([filepath,name,'_2D.xlsx'], {'GliaTrace programmed by Mahmoud Abdolhoseini, mahmoud.abdolhoseini@uon.edu.au', datestr(datetime('now'))},1,'K2')
    writetable(cellQtable,[filepath,name,'_2D.xlsx'],'Range','A5')
end












