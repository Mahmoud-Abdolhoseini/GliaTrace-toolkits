function cellinfo = main_trace(cellinfo, grayim)
%
% Preparing seed points (queue) and running tracing algorithm (mst)
%
%   cellinfo = main_trace(cellinfo, grayim)
%
%   inputs:
%           cellinfo    -cell information
%           grayim      -gray image
%
%   output:
%           cellinfo    -cell information
%
%==============================
% Nov., 2015
% May,  2016    Updated to 3D
% Dec., 2017    Updated (define mss for 3D)
% Mahmoud Abdolhoseini,
% Mahmoud.abdolhoseini@uon.edu.au
% University of Newcastle
%==============================


%image info
[yl, xl, zl] = size(grayim);
cellinfo.imsize = [yl, xl, zl];

%cell info
thresh = cellinfo.thresh;   %threshold
SomaLevel = cellinfo.SomaLevel; %soma level
nl = cellinfo.BackgroundLevel - cellinfo.SomaLevel + 1; %number of levels
mcrX=ceil(cellinfo.para.MaxCellRadius / cellinfo.para.xyRes);
if cellinfo.para.minObj
    minObj=cellinfo.para.minObj;   %minimum object area to be considered
else
    R=cellinfo.para.SomaRadius / cellinfo.para.xyRes;   %radius of minObj in pixel
    minObj=ceil(pi*R^2);   
end

% check if the image is 3D
if zl==1
    threeD=0; 
else
    threeD=1;
    mcrZ=ceil(cellinfo.para.MaxCellRadius / cellinfo.para.zStep);
end

%if 3D, put mss equals to minimum soma volume found in 3D
if threeD   
    nns = 30 / cellinfo.para.zStep;
    if nns >= zl
        sr = 1:zl;
    else
        sr = ceil((zl/2)-(nns/2)):ceil((zl/2)+(nns/2));
    end
    im=grayim(:,:,sr);
    soma3D = bwareaopen(im <= thresh(SomaLevel), minObj);
    prop3D = regionprops(soma3D, 'Area', 'Centroid');
    
    soma2D = bwareaopen(min(im,[],3) <= thresh(SomaLevel), minObj);
    prop2D = regionprops(soma2D, 'Centroid');
    
    if ~isempty(prop2D)
        ce3D=cat(1,prop3D.Centroid);
        area3D=cat(1,prop3D.Area);
        ce2D=cat(1,prop2D.Centroid);
        id=zeros(length(prop2D),1);
        for n=1:length(prop2D)
            [~,id(n)]=min((ce3D(:,1)-ce2D(n,1)).^2 + (ce3D(:,2)-ce2D(n,2)).^2);
        end
        
        %update minObj
        minObj=min(area3D(id));
    end
end
cellinfo.mss=minObj;

%soma
somas = bwareaopen(grayim <= thresh(SomaLevel), minObj);

%if 2D, fill the holes inside somas (optional)
if ~threeD
    somas = imfill(somas, 'holes');  
end

%soma info
stats = regionprops(somas, 'BoundingBox', 'Centroid', 'PixelIdxList');
% no=10;
% stats=stats(1:no);
% somas=false(yl, xl, zl);
% somas(cat(1,stats.PixelIdxList))=true;

%check if any cell is found
if isempty(stats), cellinfo.soma = []; return, end

%remove soma in touch with x-y border
bb = round(cat(1, stats.BoundingBox));
if threeD
    ind = bb(:,1)==1 | bb(:,2)==1 | bb(:,1)+bb(:,4)-1==xl | bb(:,2)+bb(:,5)-1==yl;
else
    ind = bb(:,1)==1 | bb(:,2)==1 | bb(:,1)+bb(:,3)-1==xl | bb(:,2)+bb(:,4)-1==yl;
end
somas(cat(1, stats(ind).PixelIdxList))=0;
stats=stats(~ind);

%store soma
cellinfo.soma = somas;

%soma centroids
ce = round(cat(1, stats.Centroid));     
cellinfo.SomaCentroid=ce;

%number of cells
num_cell = length(stats);
if num_cell==0; return, end

%defining ranges to crop each cell and process them individually
xrange(:,1) = ce(:,1) - mcrX;
xrange(:,2) = ce(:,1) + mcrX;
yrange(:,1) = ce(:,2) - mcrX;
yrange(:,2) = ce(:,2) + mcrX;
xrange(xrange(:,1)<1, 1)  = 1;
yrange(yrange(:,1)<1, 1)  = 1;
xrange(xrange(:,2)>xl, 2) = xl;
yrange(yrange(:,2)>yl, 2) = yl;
if threeD
    zrange(:,1) = ce(:,3) - mcrZ;
    zrange(:,2) = ce(:,3) + mcrZ;
    zrange(zrange(:,1)<1, 1)  = 1;
    zrange(zrange(:,2)>zl, 2) = zl;
end

%binary cell pixels/voxels
bw = bwareaopen(grayim <= thresh(cellinfo.BackgroundLevel), minObj);
if ~threeD
    cellinfo.bw = bw;
end

%pre-allocation of arrays which store the results
cellinfo.queue = cell(num_cell,1);   % queue
cellinfo.nsp   = cell(num_cell,1);   % number of SP in first level
cellinfo.pci   = cell(num_cell,1);   % parent-child indices

for ii = 1:num_cell
    
    if threeD
        
        % new centroid of the cell
        if xrange(ii,1)==1; nce(1)=ce(ii,1);
        else, nce(1) = mcrX + 1; end       
        if yrange(ii,1)==1; nce(2)=ce(ii,2); 
        else, nce(2) = mcrX + 1; end
        if zrange(ii,1)==1; nce(3)=ce(ii,3); 
        else, nce(3) = mcrZ + 1; end
        
        % crop
        cropped_soma= somas(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2),...
            zrange(ii,1):zrange(ii,2));
        cropped_bw = bw(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2),...
            zrange(ii,1):zrange(ii,2));
        cropped_im  = grayim(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2),...
            zrange(ii,1):zrange(ii,2));
        imSize_crop = size(cropped_im);
        
        % soma properties in the cropped region
        prop = regionprops(cropped_soma, 'BoundingBox', 'Centroid', 'PixelIdxList');
        num  = length(prop);
        nnce = round(cat(1, prop.Centroid));
        
        % soma of the cell
        if num == 1; somac = cropped_soma;
        else
            for n = 1:num
                if nnce(n,:) == nce; somaId = n; break; end
            end
            somac = false(imSize_crop);
            somac(prop(somaId).PixelIdxList)=true;
            
            %watershed
%             w=watershed(cropped_soma);
%             id= w~=w(prop(somaId).PixelIdxList(1));
%             cropped_bw1(id)=false;
        end
        
        
        % remove bounding box of other cells in the region to avoid tracing
        % branches of the close cells to the currently considering cell
        if num > 1
            filtering = true(imSize_crop);
            bbc  = round(cat(1, prop.BoundingBox));
            for n = 1:num
                if n == somaId; continue, end
                filtering(bbc(n,2):bbc(n,2)+bbc(n,5)-1, bbc(n,1):bbc(n,1)+bbc(n,4)-1,...
                    bbc(n,3):bbc(n,3)+bbc(n,6)-1) = false;
            end
            cropped_bw = (cropped_bw & filtering) | somac;
        end
        
    else %2D
        
        % new centroid of the cell
        if xrange(ii,1)==1; nce(1)=ce(ii,1);
        else, nce(1) = mcrX + 1; end       
        if yrange(ii,1)==1; nce(2)=ce(ii,2); 
        else, nce(2) = mcrX + 1; end
        
        % crop
        cropped_soma= somas(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2));
        cropped_bw = bw(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2));
        cropped_im  = grayim(yrange(ii,1):yrange(ii,2),xrange(ii,1):xrange(ii,2));
        imSize_crop  = size(cropped_im);
        
        % soma properties in the cropped region
        prop = regionprops(cropped_soma, 'BoundingBox', 'Centroid', 'PixelIdxList');
        num  = length(prop);
        nnce  = round(cat(1, prop.Centroid));
        
        % soma of the cell
        if num == 1; somac = cropped_soma;
        else
            for n = 1:num
                if nnce(n,:) == nce; somaId = n; break; end
            end
            somac = false(imSize_crop);
            somac(prop(somaId).PixelIdxList)=true;
            
            %watershed
%             w=watershed(cropped_soma);
%             id= w~=w(prop(somaId).PixelIdxList(1));
%             cropped_bw(id)=false;
        end
        
        % remove bounding box of other cells in the region to avoid tracing
        % branches of the close cells to the currently considering cell
        if num > 1
            filtering = true(imSize_crop);
            bbc  = round(cat(1, prop.BoundingBox));
            for n = 1:num
                if n == somaId; continue, end
                filtering(bbc(n,2):bbc(n,2)+bbc(n,4)-1, bbc(n,1):bbc(n,1)+bbc(n,3)-1) = false;
            end
            cropped_bw = (cropped_bw & filtering) | somac;
        end
        
    end
      
    
    %------>> Sampling
    if threeD
        win = ceil(1.7/cellinfo.para.xyRes); %length of sampling window in pixel
        seed_points = false([imSize_crop, nl]);
        soma_perim = bwperim(somac);
        seed_points(:,:,:,1) = min_win(cropped_im, win, soma_perim);
        for n = 2:nl-1
            level = cropped_im>thresh(SomaLevel+n-2) & ...
                cropped_im<=thresh(SomaLevel+n-1) & cropped_bw;
            seed_points(:,:,:,n) = min_win(cropped_im, win, level);
        end
        level = cropped_im>thresh(SomaLevel+nl-2) & ...
            cropped_im<=thresh(SomaLevel+nl-1) & cropped_bw;
        seed_points(:,:,:,nl) = min_win(cropped_im, win) & level;
    else
        win = ceil(1.5/cellinfo.para.xyRes);
        seed_points = false([imSize_crop, nl]);
        soma_perim = bwperim(somac);
        seed_points(:,:,1) = min_win(cropped_im, win, soma_perim);
        for n = 2:nl-1
            level = cropped_im>thresh(SomaLevel+n-2) & ...
                cropped_im<=thresh(SomaLevel+n-1) & cropped_bw;
            seed_points(:,:,n) = min_win(cropped_im, win, level);
        end
        level = cropped_im>thresh(SomaLevel+nl-2) & ...
            cropped_im<=thresh(SomaLevel+nl-1) & cropped_bw;
        seed_points(:,:,nl) = min_win(cropped_im, win) & level;
    end
    %------- end of sampling
    
    
    %------>> saving location of the seed points in a queue matrix
    nsp = zeros(nl,1); % number of SPs in each level
    if threeD
        queue = zeros(nnz(seed_points),3);
        summ = 0;
        for le = 1:nl
            [y, x, z] = ind2sub(size(seed_points), find(seed_points(:,:,:,le)));
            nsp(le)   = length(y);
            queue(summ+1:summ+nsp(le),:) = [x,y,z];
            summ = summ + nsp(le);
        end
    else
        queue = zeros(nnz(seed_points),2);
        summ = 0;
        for le = 1:nl
            [y, x]  = find(seed_points(:,:,le));
            nsp(le) = length(y);
            queue(summ+1:summ+nsp(le),:) = [x,y];
            summ = summ + nsp(le);
        end
    end
    nsp = nonzeros(nsp);    % update nsp
    %-------
    nq=[nce;queue];
    nsp(1)=nsp(1)+1;
    cellinfo.queue{ii} = nq;
    cellinfo.nsp{ii}   = nsp;
    
    % Applying Minimum Spanning Tree (MST) to seed points
    cellinfo = mst(cellinfo, cropped_bw);
    
end












