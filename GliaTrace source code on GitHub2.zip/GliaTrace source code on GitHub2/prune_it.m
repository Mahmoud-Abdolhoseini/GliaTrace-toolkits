function pci = prune_it(pci, start_node, end_node)
%----->> Prune branchs specified by start_node and end_node from pci
% (parents and childern ID) tree
%
% pci = prune_it(pci, start_node, end_node)
%
% inputs:
%       pci         -parents and childern ID
%       start_node
%       end_node
%
% output:
%       pci         -parents and childern ID without branchs specified by 
%                   start_node and end_node  
%
%==============================
% Author: Mahmoud Abdolhoseini,
% The University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
% Apr., 2016
%==============================
ns = length(start_node);
ne = length(end_node);
if ns==1
    for ii = 1:ne
        en = end_node(ii);
        while en ~= start_node
            idx = pci(:,2) == en;
            en  = pci(idx,1);
            pci = pci(~idx,:);
        end
    end
else
    for ii = 1:ne
        en = end_node(ii);
        while en ~= start_node(ii)
            idx = pci(:,2) == en;
            en  = pci(idx,1);
            pci = pci(~idx,:);
        end
    end
end

