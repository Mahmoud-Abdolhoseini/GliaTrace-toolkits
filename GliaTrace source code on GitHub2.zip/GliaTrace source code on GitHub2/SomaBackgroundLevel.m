function cellinfo = SomaBackgroundLevel(cellinfo, grayim)
%
% Automatically finding several thresholds to segment somas and remove
% background
%
%   cellinfo = SomaBackgroundLevel(cellinfo, grayim)
% 
% Inputs:
%     cellinfo       -cell information
%     grayim         -gray image 
%     
% Output:
%     cellinfo       -cell information
%     
%
%==============================
% Nov., 2015
% Dec., 2016 Updated (from multi_thr to SomaBackgroundLevel)
% Mahmoud Abdolhoseini,
% mahmoud.abdolhoseini@uon.edu.au
% University of Newcastle
%==============================


if cellinfo.para.minObj
    minObj=cellinfo.para.minObj;   %minimum object area to be considered
else
    R=cellinfo.para.SomaRadius / cellinfo.para.xyRes;   %radius of minObj in pixel
    minObj=ceil(pi*R^2);   
end
zl = size(grayim,3);

if zl~=1    
    % 30 micrometer (30um) in z direction almost include one soma,
    % therefore we need to pick enough number of slices in z direction to
    % assure that the z thickness is almost 30um
    nns = 30 / cellinfo.para.zStep;    % necessary number of slices
    if nns >= zl
        sr = 1:zl;    % slice range
    else
        % otherwise choose the slices from the middle of the stack image
        % (for the sake of quality)
        sr = ceil((zl/2)-(nns/2)):ceil((zl/2)+(nns/2));
    end
    grayim = min(grayim(:,:,sr),[],3);
end

%Otsu's multiple thresholds
N=20;   %number of thresholds
thresh = multithresh(grayim, N);


%count number of object in otsu's level to find the start-end intensity
%interval to begin new object counting for all intensities included in the
%interval
nob = zeros(N,1);   % number of objects
for n = 1:N 
    bw = grayim <= thresh(n);
    
    % connected component
    CC = bwconncomp(bwareaopen(bw, minObj)); 
    nob(n) = CC.NumObjects;
end

%----------------------------------BackgorundLevel (bl)
[~,bl]=max(nob);

% Background threshold
blt = thresh(bl);
bt  = thresh(bl);

% Change blt to integer if it is double
do=false;
if blt<=1
    blt=uint8(255*blt);
    do=true;
end

% Checking left neighbor indices to find absolute maximum
tmp=blt;
mv = nob(bl);   %maximum value
while true
    tmp=tmp-1; thr=tmp;
    if do; thr=double(thr)/255; end
    bw = grayim <= thr;
    CC = bwconncomp(bwareaopen(bw, minObj));
    if CC.NumObjects < mv, break; end
    thresh(bl)=thr;
    mv=CC.NumObjects;
end
if mv==nob(bl), thresh(bl)=bt; end

% Checking right neighbor indices to find absolute maximum
tmp=blt;
mv = nob(bl);
while true
    tmp=tmp+1; thr=tmp;
    if do; thr=double(thr)/255; end
    bw = grayim <= thr;
    CC = bwconncomp(bwareaopen(bw, minObj));
    if CC.NumObjects < mv, break; end
    thresh(bl)=thr;
    mv=CC.NumObjects;
end
cellinfo.thresh = thresh;
%----------------------------------End of BackgorundLevel (bl)


%----------------------------------SomaLevel
id1=find(nob,1,'first');

%Criterion, normalized first-order differential
c  =(nob(id1+1:N)-nob(id1:N-1))./(nob(id1+1:N)+nob(id1:N-1));

%non-negetive label vector
nnlv = bwlabel(c>=0); 
tmp=c(nnlv==1);

%to make sure that SomaLevel won't be chosen close to BackgroundLevel (bl)
if length(tmp)+id1-1==bl-1, tmp(bl-id1)=Inf; end

I=find(tmp==min(tmp));
li=length(I);
if li==1
    SomaLevel = I+id1-1;
else %if there is more than one minimum number, use second-order differential to specify the soma level
    if I(end)==length(c); I=I(1:end-1); end
    tmp=c(2:end)-c(1:end-1);    %second-order differential
    tmp=tmp(I);
    if tmp(end)<0; tmp=tmp(1:end-1);end
    [~,id]=min(tmp);
    SomaLevel = I(id)+id1-1;
end
%----------------------------------End of SomaLevel

% make sure that BackgroundLevel is not less than soma_level+2
if bl < SomaLevel + 2
    bl = SomaLevel + 2;
    bl(bl>N)=N;
end



if cellinfo.para.SomaLevel
    cellinfo.SomaLevel = cellinfo.para.SomaLevel;
else
    cellinfo.SomaLevel = SomaLevel;
end

if cellinfo.para.BackgroundLevel
    cellinfo.BackgroundLevel = cellinfo.para.BackgroundLevel;
else
    cellinfo.BackgroundLevel = bl;
end



% thresh(21)=250;
% thresh=thresh(2:21);
% for n = 1:N   
%     bw = grayim <= thresh(n);
%     CC = bwconncomp(bwareaopen(bw, msa)); 
%     nob(n) = CC.NumObjects;
% end
% id1=find(nob,1,'first');
% c = (nob(id1+1:N)-nob(id1:N-1))./(nob(id1+1:N)+nob(id1:N-1));
% 
% figure,
% plot(thresh(id1:N-1),c,':', 'LineWidth',2)
% ylabel('Criterion (c_i)','FontSize',12,'FontWeight','bold','Color','k')
% xlabel('Threshold (t_i)','FontSize',12,'FontWeight','bold','Color','k')
% hold on
% plot(thresh(id1:N-1),c,'xb', 'LineWidth',3, 'MarkerSize',15)
% plot(thresh(SomaLevel-1),c(SomaLevel-1-id1+1),'or', 'LineWidth',3, 'MarkerSize',30)
% hold off
% ax=gca;
% ax.LineWidth=3;
% ax.FontSize=15;
% ax.LabelFontSizeMultiplier = 2.5;
% ax.XLim=[100 260];
% axis square
% 
% figure,
% plot(thresh,nob,':', 'LineWidth',2)
% ylabel('Number of Objects (n_t)','FontSize',12,'FontWeight','bold','Color','k')
% xlabel('Threshold (t_i)','FontSize',12,'FontWeight','bold','Color','k')
% hold on
% plot(thresh,nob,'xb', 'LineWidth',3, 'MarkerSize',15)
% plot(thresh(bl-1),nob(bl-1),'or', 'LineWidth',3, 'MarkerSize',30)
% hold off
% ax=gca;
% ax.LineWidth=3;
% ax.FontSize=15;
% ax.LabelFontSizeMultiplier = 2.5;
% ax.XLim=[100 260];
% axis square



