function cellinfo = quantifyBranch(cellinfo)
% Quantify Branches
% cellinfo = quantifyBranch(cellinfo)
%
%
%
%=================================
% Apr. 2016
% Oct. 2016 updated
% Nov. 2016 updated (to start quantification from centroid)
% Dec. 2016 updated (to calculate volume using cellinfo.radii vector)
% Mahmoud Abdolhoseini,
% University of Newcastle
% mahmoud.abdolhoseini@uon.edu.au
%=================================

%check if the image is 3D
if cellinfo.imsize(3)==1
    threeD=0;
else
    threeD=1;
end

%initial value
if threeD
    cellinfo.cellQ.CellVolume=cellinfo.cellQ.SomaVolume;
else
    cellinfo.cellQ.CellArea=cellinfo.cellQ.SomaArea;
end

for n = 1:length(cellinfo.pci)
    
    pci = cellinfo.pci{n};  %parent-child id
    if isempty(pci); continue, end
    radii = cellinfo.radii{n};  %radii of the points stored in pci
    
    %number of primary branches
    npb = nnz(pci(:,1)==1);
    
    %number of branch points
    [~, ia, ~] = unique(pci(:,1),'stable');
    ind = setdiff(1:size(pci,1), ia);
    bp = unique(pci(ind,1));
    if npb==1
        nbp=length(bp);
    else
        nbp=length(bp)-1;
    end
    
    %compute total branch length and volume
    tbl=0;  %total branch length
    sn=1;   %start node
    cs=0;   %cell size (area in 2D, volume in 3D)
    [tbl, cs] = BLV(pci,radii,tbl,cs,sn);
    
    %store the quantification
    cellinfo.cellQ.NumPrimaryBranch(n) = npb;
    cellinfo.cellQ.TotalNumBranchPoint(n) = nbp;
    cellinfo.cellQ.TotalBranchLength(n) = tbl;
    if threeD
        cellinfo.cellQ.CellVolume(n) = cs + cellinfo.cellQ.SomaVolume(n);
    else
        cellinfo.cellQ.CellArea(n) = cs + cellinfo.cellQ.SomaArea(n);
    end
end


%-------------------------------------------------BLV function
    function [tbl, cs] = BLV(pci,radii,tbl,cs,sn)
        %compute total branch length and volume
        %pci    parent-child id
        %radii  radii vector
        %tbl    total branch length
        %cs     cell size (area in 2D, volume in 3D)
        %sn     start node
        %
        
        id = pci(:,1)==sn;
        el = pci(id,2:3);
        en = el(:,1);   %end node
        nc = length(en);%number of child
        bl = el(:,2);   %branch length
        V  = zeros(nc,1);   %Volume
        A  = zeros(nc,1);   %Area
        
        if sn~=1
            r1=radii(pci(:,2)==sn);
            r2=radii(id);
            if threeD
                V=pi * el(:,2) .* (r1^2 + r1*r2 + r2.^2) / 3;    
            else
                A=el(:,2) .* (r1+r2);    
            end
        end
        
        id=find(id);
        for m=1:nc
            id1=id(m);
            id2=pci(:,1)==en(m);
            
            el = pci(id2,2:3);
            while size(el,1)==1
                en(m) = el(1);
                bl(m) = bl(m)+el(2);
                
                r1=radii(id1);
                r2=radii(id2);
                if threeD
                    V(m)=V(m)+ pi * el(2) * (r1^2 + r1*r2 + r2^2) / 3;
                else
                    A(m)=A(m)+ el(2) * (r1+r2);
                end
                
                id1=id2;
                id2=pci(:,1)==en(m);
                el = pci(id2,2:3);
            end
            
            if size(el,1)>1
                if threeD
                    [bl(m), V(m)] = BLV(pci,radii,bl(m),V(m),en(m));
                else
                    [bl(m), A(m)] = BLV(pci,radii,bl(m),A(m),en(m));
                end
            end
            
        end
        
        tbl=tbl+sum(bl);
        if threeD
            cs=cs+sum(V);
        else
            cs=cs+sum(A);
        end
    end
%----------------end of BLV function


end



