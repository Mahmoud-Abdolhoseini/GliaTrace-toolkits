function plotcell(cellinfo, imarray)
%
%----->>  plot cell Morphology and skeleton
%
%   plotcell(cellinfo, imarray, nn)
%
%   inputs:
%           cellinfo    -cell information
%           imarray     -image array
%           nn          -number of file
%
%==============================
% Author: Mahmoud Abdolhoseini,
% University of Newcastle
% Mahmoud.abdolhoseini@uon.edu.au
% Apr. 2016
% Nov. 2016 updated (to plot the smoothed path)
% Dec. 2016 updated (to visualize volume using cellinfo.radii)
%==============================




% cell info
num_cell = length(cellinfo.pci);    %number of cells
ce=cellinfo.SomaCentroid;   %centroid of the somas
[~,name,~] = fileparts(cellinfo.filename{cellinfo.counter});

% make a result folder to store results
if ~exist([cellinfo.filepath,'results'],'dir')
    mkdir(cellinfo.filepath,'results')
end
filepath=[cellinfo.filepath,'results\'];

% image info
yl = cellinfo.imsize(1);
xl = cellinfo.imsize(2);
zl = cellinfo.imsize(3);

% check if it is 3D
if zl==1
    threeD=0;
else
    threeD=1;
end


cellinfo.para.visual3D = 'all';
if threeD
    ra = cellinfo.para.visual3D;
    if ra~=0
        if ischar(ra)
            ra=1:num_cell;
            
            %save image with and without numbering cells
            f=figure;
            if isfield(imarray.twoD, 'colored')
                imshow(imarray.twoD.colored,[])
            else
                imshow(imarray.twoD.gray,[])
            end
            saveas(f,[filepath,name,'_Cell','.png'])
            hold on
            for n = 1:num_cell
                text(ce(n,1),ce(n,2), num2str(n), 'Color', 'r', 'FontSize', 20);
            end
            hold off
            figure(f), title('Cell No.')
            saveas(f,[filepath,name,'_CellNumber_3D','.png'])
        end
        
        %soma info
%         somaInfo = regionprops(cellinfo.soma, 'PixelList');
%             cor = somaInfo(ii).PixelList;
%             plot3(cor(:,1),cor(:,2),cor(:,3),'k.')
        
            % An sphere representing soma area
%             sr  = cellinfo.radii{ii}(end)/cellinfo.para.xyRes;  %soma radius
%             [x,y,z]=ellipsoid(ce(ii,1),ce(ii,2),ce(ii,3),sr,sr,sr/scaling,20);
%             surf(x, y, z, 'FaceColor', [0,0,0], 'LineStyle', 'none')


        %--------first plot: cell skeleton
        f1=figSetting; 
        for n=ra
            if isempty(cellinfo.pci{n}); continue, end
            
            %find the seedpoints location
            [p,c]=spLocation(cellinfo,n);
            
            %make a plot by connecting seedpoints
            hold on
            for m = 1:size(p,1)
                plot3([p(m,1),c(m,1)],[p(m,2),c(m,2)],[p(m,3),c(m,3)],...
                    'Color','k')
            end
            hold off
        end
        figure(f1), title('3D Skeleton')
        axis off
        saveas(f1,[filepath,name,'_Skeleton_3D','.png'])
        axis on, view(3), 
        %--------end of first plot
        
        %--------second plot: cell volume (considering thickness of branches)
        f2=figSetting; 
        for n=ra
            if isempty(cellinfo.pci{n}); continue, end
            
            %find the seedpoints location
            [p,c]=spLocation(cellinfo,n);
            
            %radii in pixel
            R=cellinfo.radii{n}/cellinfo.para.xyRes;
            
            %make a plot by connecting seedpoints
            hold on
            for m = 1:size(p,1)
                plot3([p(m,1),c(m,1)],[p(m,2),c(m,2)],[p(m,3),c(m,3)],...
                    'Color','k', 'LineWidth', R(m))
            end
            hold off
        end
        figure(f2), title('Cell Volumes')
        axis off
        saveas(f2,[filepath,name,'_CellVolume','.png'])
        axis on, view(3)
        %--------end of second plot
        
        %--------third plot: the smooth path if there is any!
        if isfield(cellinfo, 'path')
            f3=figSetting;
            for n=ra
                path = cellinfo.path{n};
                if isempty(path); continue, end
                cec = cellinfo.queue{n}(1,:);
                ind=find(path(:,1)==0);
                
                % shift the path to the orginal image size
                path(:,1) = path(:,1) + ce(n,1) - cec(1);
                path(:,2) = path(:,2) + ce(n,2) - cec(2);
                path(:,3) = path(:,3) + ce(n,3) - cec(3);
                
                hold on
                if isempty(ind)
                    plot3(path(:,1),path(:,2),path(:,3),'k')
                else
                    plot3(path(1:ind(1)-1,1),path(1:ind(1)-1,2),path(1:ind(1)-1,3),'k')
                    plot3(path(ind(end)+1:end,1),path(ind(end)+1:end,2),path(ind(end)+1:end,3),'k')
                    for m=2:length(ind)
                        t=path(ind(m-1)+1:ind(m)-1,:);
                        plot3(t(:,1),t(:,2),t(:,3),'k')
                    end
                end
                hold off
            end
            figure(f3), view(3), title('Skeleton With Smoothing')
        end
        %--------end of third plot
        
    end
    
else %2D
    
    %save image with and without numbering cells
    f=figure;
    if isfield(imarray.twoD, 'colored')
        imshow(imarray.twoD.colored,[])
    else
        imshow(imarray.twoD.gray,[])
    end
    saveas(f,[filepath,name,'_Cell','.png'])
    hold on
    for n = 1:num_cell
        text(ce(n,1),ce(n,2), num2str(n), 'Color', 'r', 'FontSize', 20);
    end
    hold off
    figure(f), title('Cell No.')
    saveas(f,[filepath,name,'_CellNumber_2D','.png'])
    
    %--------first plot: cell skeleton
    f1=figure; imshow(~cellinfo.soma), title('2D Skeleton')
    for n=1:num_cell
        if isempty(cellinfo.pci{n}); continue, end
        
        %find the seedpoints location
        [p,c]=spLocation(cellinfo,n);
        
        hold on
        for m = 1:size(p,1)
            plot([p(m,1),c(m,1)],[p(m,2),c(m,2)],'Color','k')
        end
        hold off
    end
    saveas(f1,[filepath,name,'_Skeleton_2D','.png'])
    %--------end of first plot
    
    %--------second plot: cell area
    f2=figure; imshow(((~cellinfo.soma))), title('Cell Areas')
    for n=1:num_cell
        if isempty(cellinfo.pci{n}); continue, end
        
        %find the seedpoints location
        [p,c]=spLocation(cellinfo,n);
        
        %radii in pixel
        R=cellinfo.radii{n}/cellinfo.para.xyRes;
            
        hold on
        for m = 1:size(p,1)
            plot([p(m,1),c(m,1)],[p(m,2),c(m,2)],'Color','k',...
                'LineWidth', R(m))
        end
        hold off
    end
    saveas(f2,[filepath,name,'_CellArea','.png'])
    %--------end of second plot
    
    %--------third plot: the smoothed path
    if isfield(cellinfo, 'path')
        f3=figure; imshow(~cellinfo.soma), title('Skeleton With Smoothing')
        for n=1:num_cell
            path = cellinfo.path{n};
            if isempty(path); continue, end
            cec = cellinfo.queue{n}(1,:); %soma centroid in the cropped area
            ind=find(path(:,1)==0);
            
            % shift the path to the orginal image size
            path(:,1) = path(:,1) + ce(n,1) - cec(1);
            path(:,2) = path(:,2) + ce(n,2) - cec(2);
            
            hold on
            if isempty(ind)
                plot(path(:,1),path(:,2),'k')
            else
                plot(path(1:ind(1)-1,1),path(1:ind(1)-1,2),'k')
                plot(path(ind(end)+1:end,1),path(ind(end)+1:end,2),'k')
                for m=2:length(ind)
                    t=path(ind(m-1)+1:ind(m)-1,:);
                    plot(t(:,1),t(:,2),'k')
                end
            end
            hold off
        end
        saveas(f3,[filepath,name,'_Skeleton_Smoothed','.png'])  
    end
    %--------end of third plot
    
end




%----------------------------function figureSetting
    function f=figSetting
        %make an empty figure and design a setting
        %
        
        f=figure;
        h = axes;
        h.YDir='reverse'; h.ZDir='reverse';
        h.XLim=[1 xl]; h.YLim=[1 yl]; h.ZLim=[1 zl];
        h.XLabel.String='x'; h.YLabel.String='y'; h.ZLabel.String='z';
%         axis off
        %axis square
    end
%----------------------------end of figureSetting
    
        

%---------------------------function spLocation
    function [p,c]=spLocation(cellinfo,n)
        %find the seedpoints location
        %
        
        pci = cellinfo.pci{n};
        cec = cellinfo.queue{n}(1,:);  %soma centroid
        p = cellinfo.queue{n}(pci(:,1),:);  % parent
        c = cellinfo.queue{n}(pci(:,2),:);  % child
        
        % shift pci locations to original image size
        p(:,1) = p(:,1) + ce(n,1) - cec(1);
        p(:,2) = p(:,2) + ce(n,2) - cec(2);
        c(:,1) = c(:,1) + ce(n,1) - cec(1);
        c(:,2) = c(:,2) + ce(n,2) - cec(2);
        if threeD
            p(:,3) = p(:,3) + ce(n,3) - cec(3);
            c(:,3) = c(:,3) + ce(n,3) - cec(3);
        end
    end
%---------------------------end of spLocation


end








